from pathlib import Path
from typing import List, Tuple, Optional, Union
from random import choice

import numpy as np
import torch
from torch.utils.data import Dataset
from torchvision import transforms as tf
import cv2
from typeguard import typechecked
from einops import rearrange

from geometry import get_opencv_pixel_coordinates
from utils import *
from functools import lru_cache
import torch.nn.functional as F
from PIL import Image, ImageFile
from numpy import random

ImageFile.LOAD_TRUNCATED_IMAGES = True


try:
    pass
except ImportError:
    pass
import os

# Stage = Literal["tain", "test", "val"]


class NMR360Dataset(Dataset):
    root: Path
    stage: str
    examples: List[Tuple[str, str]]

    # z_near: float = 0.6
    z_near: float = 0.62
    z_far: float = 2.37
    lindisp: bool = False
    overfit_to_index: Optional[int]
    num_context: int
    num_target: int
    background_color: torch.tensor = torch.tensor([0.0, 0.0, 0.0], dtype=torch.float32)
    # background_color: torch.tensor = torch.tensor([1.0, 1.0, 1.0], dtype=torch.float32)
    image_size: int = 64
    border: int = 32

    @typechecked
    def __init__(
        self,
        root: Union[str, Path] = Path("datasets/NMR"),
        stage: str = "train",
        list_prefix: str = "",
        num_context: int = 1,
        num_target: int = 2,
        overfit_to_index: Optional[int] = None,
        onlycars: bool = False,
        small_baseline: bool = False,
    ) -> None:
        super().__init__()
        self.stage = stage
        # self.root = Path(root)
        self.overfit_to_index = overfit_to_index
        self.max_num_context = num_context
        self.num_target = num_target
        self.small_baseline = small_baseline

        # Load the image and linearly remap to range [-1, 1].
        self.to_tensor = tf.ToTensor()

        self.root = Path(root)
        # Map category IDs to lists of object IDs.
        # Map category IDs to lists of object IDs.
        self.examples = []
        list_name = f"{list_prefix}{stage}.lst"
        print(f"Loading {list_name}...")
        categories = [path for path in self.root.iterdir() if path.is_dir()]
        for category in categories:
            if onlycars and "02958343" not in category.name:  # only use cars
                print("skipping", category.name)
                continue
            with (category / list_name).open("r") as f:
                ids = [id.strip() for id in f.readlines()]
            for id in ids:
                if os.path.exists(category / id / "rgb"):
                    self.examples.append((category.name, id))
        self.normalize = normalize_to_neg_one_to_one
        self.xy_pix = get_opencv_pixel_coordinates(
            x_resolution=self.image_size, y_resolution=self.image_size
        )

    @typechecked
    def get_image_paths(self, example: Tuple[str, str]) -> List[Path]:
        """Retrieve image paths for a single training example."""
        category, id = example
        example_root = self.root / category / id
        return [
            path
            for path in sorted((example_root / "rgb").iterdir())
            if path.suffix == ".png"
        ]

    def read_extrinsics(self, image_path: Path):
        extrinsic_file = (
            image_path.parents[1] / "pose" / image_path.name.replace(".png", ".txt")
        )
        extrinsics = np.loadtxt(extrinsic_file)
        extrinsics = torch.tensor(extrinsics, dtype=torch.float32).view(4, 4)
        return extrinsics

    # @lru_cache(maxsize=None)
    def read_image(self, image_path: Path):
        """Read an image with its associated camera metadata."""
        # raw_image = cv2.imread(str(image_path))
        # image = self.to_tensor(raw_image)
        image = (
            torch.tensor(
                np.asarray(Image.open(image_path)).astype(np.float32)[
                    self.border : -self.border, self.border : -self.border, :
                ]
            ).permute(2, 0, 1)
            / 255.0
        )
        image = F.interpolate(
            image.unsqueeze(0),
            size=(self.image_size, self.image_size),
            mode="bilinear",
        )[0]
        # print(f"image shape {image.shape}")
        # compute float mask from image where black is background
        mask = (image[3] > 1e-3)[None, ...].float()
        image = image[:3]
        # image = image[:3] + (1 - mask) * self.background_color[:, None, None]
        # print number of ones in the mask
        # print(f"mask sum {torch.sum(mask)}, shape {mask.shape}, dtype {mask.dtype}")

        file = open(image_path.parents[1] / "intrinsics.txt", "r")
        f, cx, cy, _ = map(float, file.readline().split())

        c, h, w = image.shape
        assert np.allclose(h, w)
        c = 0.5
        f = f * c / cx
        intrinsics = torch.tensor(
            [[f, 0, c], [0, f, c], [0, 0, 1]], dtype=torch.float32
        )
        extrinsics = self.read_extrinsics(image_path)

        return {
            "image": image,
            "mask": mask,
            "extrinsics_c2w": extrinsics,
            "intrinsics": intrinsics,
        }

    def read_images(self, image_paths: List[Path]):
        """Read a list of images with their associated camera metadata."""
        images = []
        for image_path in image_paths:
            images.append(self.read_image(image_path))
        return images

    @typechecked
    def __len__(self) -> int:
        return len(self.examples)

    @typechecked
    def get_image_paths(self, example: Tuple[str, str]) -> List[Path]:
        """Retrieve image paths for a single training example."""
        category, id = example
        example_root = self.root / category / id
        return [
            path
            for path in sorted((example_root / "rgb").iterdir())
            if path.suffix == ".png"
        ]

    # @lru_cache(maxsize=None)
    def __getitem__(self, index: int):
        # randomize index
        index = random.randint(0, len(self))

        def fallback():
            """Fallback to a random example if we can't find a valid one."""
            return self[random.randint(0, len(self))]

        # Use the index to select the positive example.
        rendered_object = self.examples[
            index if self.overfit_to_index is None else self.overfit_to_index
        ]

        # Fetch the number of images in the rendered and other example.
        image_paths_rendered = self.get_image_paths(rendered_object)
        num_context = self.max_num_context
        # print(f"num_context {num_context}")
        image_paths = np.random.choice(
            image_paths_rendered, self.num_target + num_context, replace=False
        )
        target_image_paths = image_paths[: self.num_target]
        context_image_paths = image_paths[self.num_target :]

        if self.small_baseline:
            # read extrinsics of the first context and target image
            ctxt_extrinsics = self.read_extrinsics(context_image_paths[0])
            trgt_extrinsics = self.read_extrinsics(target_image_paths[0])
            trgt_rot = trgt_extrinsics[:3, :3]
            ctxt_rot = ctxt_extrinsics[:3, :3]
            rel_rot = torch.matmul(trgt_rot, torch.inverse(ctxt_rot))
            # compute angle
            angle = torch.acos((torch.trace(rel_rot) - 1) / 2)
            angle = angle * 180 / math.pi
            if angle > 90:
                # print(f"rot_dist {angle}")
                return fallback()

        rendered = self.read_images(target_image_paths)
        context = self.read_images(context_image_paths)

        _, h, w = context[0]["image"].shape

        trgt_c2w = [r["extrinsics_c2w"] for r in rendered]
        ctxt_c2w = [r["extrinsics_c2w"] for r in context]

        trgt_c2w = torch.stack(trgt_c2w)
        ctxt_c2w = torch.stack(ctxt_c2w)

        inv_ctxt_c2w = torch.inverse(ctxt_c2w[0])

        trgt_rgb = [self.normalize(r["image"]) for r in rendered]
        trgt_rgb = torch.stack(trgt_rgb)
        ctxt_rgb = [self.normalize(r["image"]) for r in context]
        ctxt_rgb = torch.stack(ctxt_rgb)

        trgt_masks = [r["mask"] for r in rendered]
        trgt_masks = torch.stack(trgt_masks)

        inv_ctxt_c2w_repeat = inv_ctxt_c2w.unsqueeze(0).repeat(trgt_rgb.shape[0], 1, 1)
        ctxt_inv_ctxt_c2w_repeat = inv_ctxt_c2w.unsqueeze(0).repeat(
            ctxt_rgb.shape[0], 1, 1
        )
        return (
            {
                "ctxt_c2w": torch.einsum(
                    "ijk, ikl -> ijl", ctxt_inv_ctxt_c2w_repeat, ctxt_c2w
                ),
                "trgt_c2w": torch.einsum(
                    "ijk, ikl -> ijl", inv_ctxt_c2w_repeat, trgt_c2w
                ),
                "ctxt_rgb": ctxt_rgb,
                "trgt_rgb": trgt_rgb,
                # "trgt_masks": trgt_masks,
                "intrinsics": context[0]["intrinsics"],
                "x_pix": rearrange(self.xy_pix, "h w c -> (h w) c"),
                "idx": torch.tensor([index]),
                "image_shape": torch.tensor([h, w, 3]),
            },
            trgt_rgb,  # rearrange(rendered["image"], "c h w -> (h w) c"),
        )

    def data_for_video(self, video_idx, ctxt_idx, trgt_idx):
        # index = random.randint(0, len(self.examples) - 1)
        index = video_idx
        # print("ignoring video_idx")
        rendered_object = self.examples[index]
        image_paths_rendered = self.get_image_paths(rendered_object)

        print(f"trgt_idx {trgt_idx} ctxt_idx {ctxt_idx}")
        target_image_paths = [image_paths_rendered[i] for i in trgt_idx]
        context_image_paths = [image_paths_rendered[i] for i in ctxt_idx]

        # read extrinsics of the first context and target image
        if self.small_baseline:
            ctxt_extrinsics = self.read_extrinsics(context_image_paths[0])
            trgt_extrinsics = self.read_extrinsics(target_image_paths[0])
            trgt_rot = trgt_extrinsics[:3, :3]
            ctxt_rot = ctxt_extrinsics[:3, :3]
            rel_rot = torch.matmul(trgt_rot, torch.inverse(ctxt_rot))
            # compute angle
            angle = torch.acos((torch.trace(rel_rot) - 1) / 2)
            angle = angle * 180 / math.pi
            if angle > 90:
                # print(f"rot_dist {angle}")
                trgt_idx = np.array(
                    [random.randint(0, len(image_paths_rendered) - 1)], dtype=np.int64
                )
                return self.data_for_video(video_idx, ctxt_idx, trgt_idx)

        rendered = self.read_images(target_image_paths)
        context = self.read_images(context_image_paths)

        _, h, w = context[0]["image"].shape

        trgt_c2w = [r["extrinsics_c2w"] for r in rendered]
        trgt_c2w = torch.stack(trgt_c2w)

        ctxt_c2w = [r["extrinsics_c2w"] for r in context]
        ctxt_c2w = torch.stack(ctxt_c2w)

        inv_ctxt_c2w = torch.inverse(ctxt_c2w[0])

        trgt_rgb = [self.normalize(r["image"]) for r in rendered]
        trgt_rgb = torch.stack(trgt_rgb)
        ctxt_rgb = [self.normalize(r["image"]) for r in context]
        ctxt_rgb = torch.stack(ctxt_rgb)

        inv_ctxt_c2w_repeat = inv_ctxt_c2w.unsqueeze(0).repeat(trgt_rgb.shape[0], 1, 1)
        ctxt_inv_ctxt_c2w_repeat = inv_ctxt_c2w.unsqueeze(0).repeat(
            ctxt_rgb.shape[0], 1, 1
        )
        return (
            {
                "ctxt_c2w": torch.einsum(
                    "ijk, ikl -> ijl", ctxt_inv_ctxt_c2w_repeat, ctxt_c2w
                ),
                "trgt_c2w": torch.einsum(
                    "ijk, ikl -> ijl", inv_ctxt_c2w_repeat, trgt_c2w
                ),
                "inv_ctxt_c2w": ctxt_inv_ctxt_c2w_repeat,
                "ctxt_rgb": ctxt_rgb,
                "trgt_rgb": trgt_rgb,
                "intrinsics": context[0]["intrinsics"],
                "x_pix": rearrange(self.xy_pix, "h w c -> (h w) c"),
                "image_shape": torch.tensor([h, w, 3]),
                "idx": torch.tensor([index]),
            },
            None,  # rearrange(rendered["image"], "c h w -> (h w) c"),
        )
