from functools import lru_cache
from pathlib import Path
from typing import List, Optional, Tuple, Union

import numpy as np
import torch
import torch.nn.functional as F
import torchvision.transforms as tf
from einops import rearrange, repeat
from torch.utils.data import Dataset
from numpy.random import default_rng
from utils import *
from geometry import get_opencv_pixel_coordinates
from numpy import random
import scipy
import cv2
from PIL import Image

try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal


Stage = Literal["train", "test", "val"]
import os


def list_folders(path, stage):
    up_dirs = [f for f in os.listdir(path) if os.path.isdir(os.path.join(path, f))]
    next_dirs = []
    for up_dir in up_dirs:
        list_dirs = sorted(os.listdir(os.path.join(path, up_dir)))
        if stage == "train":
            list_dirs = list_dirs[: int(len(list_dirs) * 0.95)]
        elif stage == "test":
            list_dirs = list_dirs[int(len(list_dirs) * 0.95) :]

        next_dirs += [
            os.path.join(os.path.join(path, up_dir), f)
            for f in list_dirs
            if os.path.isdir(os.path.join(path, up_dir, f))
        ]
    return next_dirs


# Example usage
class UCFDataset(Dataset):
    examples: List[Path]
    pose_root: Path
    stage: Stage
    to_tensor: tf.ToTensor
    overfit_to_index: Optional[int]
    num_target: int
    context_min_distance: int
    context_max_distance: int

    z_near: float = 0.1
    z_far: float = 10.0
    # image_size: int = 128
    image_size: int = 64
    background_color: torch.tensor = torch.tensor([1.0, 1.0, 1.0], dtype=torch.float32)

    def __init__(
        self,
        root: Union[str, Path],
        num_target: int,
        num_context: int,
        context_min_distance: int,
        context_max_distance: int,
        overfit_to_index: Optional[int] = None,
        stage: Stage = "train",
    ) -> None:
        super().__init__()
        self.overfit_to_index = overfit_to_index
        self.num_target = num_target
        self.num_context = num_context
        self.context_min_distance = context_min_distance
        self.context_max_distance = context_max_distance

        # Ensure that all data loaders use the same image when overfitting.
        if overfit_to_index is not None:
            stage = "train"

        self.examples = list_folders(root, stage=stage)
        print(f"Found {len(self.examples)} examples in {root}")

        self.to_tensor = tf.ToTensor()
        self.rng = default_rng()
        self.normalize = normalize_to_neg_one_to_one
        self.xy_pix = get_opencv_pixel_coordinates(
            x_resolution=self.image_size, y_resolution=self.image_size
        )

    def __len__(self) -> int:
        return len(self.examples)

    def read_image(self, rgb_files, id):
        rgb_file = rgb_files[id]
        rgb = (
            torch.tensor(np.asarray(Image.open(rgb_file)).astype(np.float32)).permute(
                2, 0, 1
            )[:, :, 40:-40]
            / 255.0
        )
        # print(rgb.shape, "SHAPE")
        rgb = F.interpolate(
            rgb.unsqueeze(0),
            size=(self.image_size, self.image_size),
            mode="bilinear",
            antialias=True,
        )[0]

        return rgb

    def __getitem__(self, index: int):
        if self.overfit_to_index is not None:
            index = self.overfit_to_index

        def fallback():
            """Used if the desired index can't be loaded."""
            return self[random.randint(0, len(self.examples) - 1)]

        # Retrieve a sorted (by time) list of frames.
        example = self.examples[index]
        # list all the files in the folder ending with jpg or png
        rgb_files = [
            os.path.join(example, f)
            for f in os.listdir(example)
            if f.endswith(".jpg") or f.endswith(".png")
        ]

        # frame_names = list(example)
        rgb_files = sorted(
            rgb_files, key=lambda x: int(x.split("/")[-1].split(".")[0][6:])
        )[15:]
        num_frames = len(rgb_files)

        if num_frames < self.num_target + 1:
            return fallback()

        start_idx = self.rng.choice(len(rgb_files), 1)[0]

        context_min_distance = self.context_min_distance  # * self.num_context
        context_max_distance = self.context_max_distance  # * self.num_context

        end_idx = self.rng.choice(
            np.arange(
                start_idx + context_min_distance, start_idx + context_max_distance,
            ),
            1,
            replace=False,
        )[0]
        if end_idx >= len(rgb_files):
            return fallback()
        trgt_idx = self.rng.choice(
            np.arange(start_idx, end_idx), self.num_target, replace=False
        )

        if self.num_context == 1:
            ctxt_idx = [start_idx]
            trgt_idx[0] = end_idx
        else:
            ctxt_idx = [start_idx, end_idx]

        # sort the target indices decreasingly
        trgt_idx = np.sort(trgt_idx)[::-1]

        trgt_rgbs = []
        for id in trgt_idx:
            rgb = self.read_image(rgb_files, id)
            trgt_rgbs.append(rgb)
        trgt_rgb = torch.stack(trgt_rgbs, axis=0)

        # load the ctxt
        ctxt_rgbs = []
        for id in ctxt_idx:
            rgb = self.read_image(rgb_files, id)
            ctxt_rgbs.append(rgb)
        ctxt_rgb = torch.stack(ctxt_rgbs, axis=0)

        return (
            {
                "ctxt_rgb": self.normalize(ctxt_rgb),
                "trgt_rgb": self.normalize(trgt_rgb),
                "x_pix": rearrange(self.xy_pix, "h w c -> (h w) c"),
                "idx": torch.tensor([index]),
                "image_shape": torch.tensor([self.image_size, self.image_size, 3]),
            },
            trgt_rgb,  # rearrange(rendered["image"], "c h w -> (h w) c"),
        )

    def data_for_video(self, video_idx, ctxt_idx, trgt_idx):
        scene_idx = video_idx
        example = self.examples[scene_idx]
        # list all the files in the folder ending with jpg or png
        rgb_files = [
            os.path.join(example, f)
            for f in os.listdir(example)
            if f.endswith(".jpg") or f.endswith(".png")
        ]
        # frame_names = list(example)
        rgb_files = sorted(
            rgb_files, key=lambda x: int(x.split("/")[-1].split(".")[0][6:])
        )

        trgt_rgbs = []
        for id in trgt_idx:
            id = min(id, len(rgb_files) - 1)
            rgb = self.read_image(rgb_files, id)
            trgt_rgbs.append(rgb)
        trgt_rgb = torch.stack(trgt_rgbs, axis=0)

        # load the ctxt
        ctxt_rgbs = []
        for id in ctxt_idx:
            id = min(id, len(rgb_files) - 1)
            rgb = self.read_image(rgb_files, id)
            ctxt_rgbs.append(rgb)
        ctxt_rgb = torch.stack(ctxt_rgbs, axis=0)

        return (
            {
                "ctxt_rgb": self.normalize(ctxt_rgb),
                "trgt_rgb": self.normalize(trgt_rgb),
                "x_pix": rearrange(self.xy_pix, "h w c -> (h w) c"),
                "image_shape": torch.tensor([self.image_size, self.image_size, 3]),
            },
            trgt_rgb,  # rearrange(rendered["image"], "c h w -> (h w) c"),
        )
