import os.path

from omegaconf import DictConfig
from torch.utils.data import Dataset

from data_io.images import ImageDataset
from data_io.NMR import NMRImagesDataset
from data_io.NMR import NMRDataset
from data_io.NMR360 import NMR360Dataset
from data_io.SM import SMDataset
from data_io.SRNCars import SRNDataset
from data_io.rooms import RoomDataset
from data_io.realestate10k import RealEstate10kDataset, RealEstate10kDatasetOM
from data_io.UCF import UCFDataset
import platform
from data_io.SwissRoll import SwissRollDataset
from data_io.co3d_new import CO3DDataset
from data_io.Vimeo import VimeoDataset


def get_path(dataset_name: str) -> str:
    if dataset_name == "SM":
        return {
            "openmind": "/scratch2/weka/tenenbaum/ayusht/datasets/shepherd-metzler",
            "satori": "/nobackup/nvme1/shephard-metzler/",
            "schadenfreude": "/nobackup/nvme1/shephard-metzler/",
        }
    elif dataset_name == "NMR":
        return {
            "openmind": "/om/data/public/RealEstate10k/NMR_Dataset/",
            "satori": "/nobackup/users/charatan/datasets/NMR_Dataset",
            "schadenfreude": "/nobackup/nvme1/NMR",
        }
    elif dataset_name == "NMR360":
        return {
            "openmind": "/om2/group/nklab/tom/image_sets/images_raw/NMR360_hdri/",
            "satori": "/nobackup/users/charatan/datasets/NMR_Dataset",
            "schadenfreude": "/nobackup/nvme1/NMR360_hdri/NMR360_hdri",
        }
    elif dataset_name == "SRNCars":
        return {
            "openmind": "/om2/group/nklab/tom/image_sets/srn_cars/",
            "satori": "/om2/group/nklab/tom/image_sets/srn_cars/",
            "schadenfreude": "/nobackup/nvme1/srncars_pn/",
        }
    elif dataset_name == "rooms":
        return {
            "openmind": "/om/data/public/RealEstate10k/rooms/",
            "satori": "/om2/group/nklab/tom/image_sets/srn_cars/",
            "schadenfreude": "/nobackup/nvme1/srncars_pn/",
        }
    elif dataset_name == "rooms_same_lookat":
        return {
            "openmind": "/scratch2/weka/tenenbaum/ayusht/datasets/rooms/same_look_at/",
            "satori": "/om2/group/nklab/tom/image_sets/srn_cars/",
            "schadenfreude": "/nobackup/nvme1/rooms/same_look_at/",
        }
    elif dataset_name == "rooms_smooth":
        return {
            "openmind": "/scratch2/weka/tenenbaum/ayusht/datasets/rooms/smooth/",
            "satori": "/om2/group/nklab/tom/image_sets/srn_cars/",
            "schadenfreude": "/nobackup/nvme1/rooms/smooth/",
        }
    elif dataset_name == "rooms_rotation":
        return {
            "openmind": "/scratch2/weka/tenenbaum/ayusht/datasets/rooms/smooth_rotation/",
            "satori": "/om2/group/nklab/tom/image_sets/srn_cars/",
            "schadenfreude": "/nobackup/nvme1/rooms/smooth_rotation/",
        }
    elif dataset_name == "rooms_objects":
        return {
            "openmind": "/scratch2/weka/tenenbaum/ayusht/datasets/rooms/smooth_objects/",
            "satori": "/om2/group/nklab/tom/image_sets/srn_cars/",
            "schadenfreude": "/nobackup/nvme1/rooms/smooth_rotation/",
        }
    elif dataset_name == "realestate10k":
        return {
            "openmind": "/om2/om/data/public/RealEstate10k/",
            "satori": "/om2/om/group/nklab/tom/image_sets/srn_cars/",
            "schadenfreude": "/nobackup/nvme1/RealEstate10k/",
        }
    elif dataset_name == "UCF":
        return {
            "openmind": "/scratch2/weka/tenenbaum/ayusht/datasets/UCF101/UCF-101/",
            "satori": "/om2/group/nklab/tom/image_sets/srn_cars/",
            "schadenfreude": "/nobackup/nvme1/RealEstate10k/",
        }
    elif dataset_name in ["CO3D", "CO3DPN"]:
        return {
            "supercloud": "/home/gridsan/tyin/Datasets/co3d",
            "openmind": "/om2/om/data/public/RealEstate10k/CO3DV2/CO3Dv2/",
        }
    elif dataset_name == "Vimeo":
        return {
            "openmind": "/scratch2/weka/tenenbaum/ayusht/datasets/Vimeo/vimeo_triplet/",
            "schadenfreude": "/nobackup/nvme1/Vimeo/vimeo_triplet/",
        }


def get_dataset(config: DictConfig) -> Dataset:
    name = config.dataset.name
    del config.dataset.name

    node = platform.node()
    if len(node) == 7:
        cluster = "openmind"
    elif len(node) == 8:
        cluster = "satori"
    else:
        cluster = "schadenfreude"

    if "apollo" in node:
        cluster = "openmind"
    if name == "celeba":
        return ImageDataset(
            folder=config.dataset.root,
            image_size=64,
            augment_horizontal_flip=True,
            convert_image_to=None,
        )
    elif name == "NMR_images":
        return NMRImagesDataset(root=config.dataset.root, image_size=64)
    elif name == "NMR":
        paths = get_path(name)
        return NMRDataset(
            root=paths[cluster],
            num_context=config.num_context,
            num_target=config.num_target,
            # overfit_to_index=config.dataset.overfit_to_index,
        )
    elif name == "NMR360":
        paths = get_path(name)
        return NMR360Dataset(
            root=paths[cluster],
            stage=config.stage,
            num_context=config.num_context,
            num_target=config.num_target,
            overfit_to_index=config.dataset.overfit_to_index,
            onlycars=config.onlycars,
            small_baseline=True,
            # small_baseline=False,
        )

    elif name == "SM":
        paths = get_path(name)
        if name == "SM":
            stage = "train"
        elif name == "SRNCars":
            stage = "cars_train"

        return SMDataset(
            near=config.dataset.near,
            far=config.dataset.far,
            stage=stage,
            root=paths[cluster],
            num_target=config.num_target,
            overfit_to_index=config.dataset.overfit_to_index,
        )
    elif name == "SRNCars":
        paths = get_path(name)
        return SRNDataset(
            near=config.dataset.near,
            far=config.dataset.far,
            stage="cars_train",
            root=paths[cluster],
            num_target=config.num_target,
            overfit_to_index=config.dataset.overfit_to_index,
        )
    elif "rooms" in name:
        paths = get_path(name)
        return RoomDataset(
            near=config.dataset.near,
            far=config.dataset.far,
            stage="",
            root=paths[cluster],
            num_target=config.num_target,
            num_context=config.num_context,
            overfit_to_index=config.dataset.overfit_to_index,
        )
    elif name == "realestate10k":
        paths = get_path(name)
        # min_distance = 30
        # max_distance = 90
        if cluster == "schadenfreude":
            return RealEstate10kDatasetOM(
                root=paths[cluster],
                num_context=config.num_context,
                num_target=config.num_target,
                context_min_distance=config.ctxt_min,
                context_max_distance=config.ctxt_max,
                max_scenes=config.max_scenes,
                stage=config.stage,
                image_size=config.image_size,
            )
        elif cluster == "openmind":
            return RealEstate10kDatasetOM(
                root=paths[cluster],
                num_context=config.num_context,
                num_target=config.num_target,
                context_min_distance=config.ctxt_min,
                context_max_distance=config.ctxt_max,
                max_scenes=config.max_scenes,
                stage=config.stage,
                image_size=config.image_size,
            )
    elif name == "UCF":
        paths = get_path(name)
        if cluster == "schadenfreude":
            return RealEstate10kDataset(
                image_root=os.path.join(paths[cluster], "images"),
                pose_root=os.path.join(paths[cluster], "poses"),
                num_target=config.num_target,
                overfit_to_index=config.dataset.overfit_to_index,
                context_min_distance=config.ctxt_min,
                context_max_distance=config.ctxt_max,
                stage=config.stage,
            )
        elif cluster == "openmind":
            return UCFDataset(
                root=paths[cluster],
                num_context=config.num_context,
                num_target=config.num_target,
                context_min_distance=config.ctxt_min,
                context_max_distance=config.ctxt_max,
                stage=config.stage,
            )
    elif name == "SwissRoll":
        return SwissRollDataset(num_context=1, num_target=1,)
    elif name == "CO3D":
        paths = get_path(name)

        if config.all_class:
            categories = ["apple", "ball",  "bench",  "cake",  "donut",  "hydrant", "plant", "suitcase", "teddybear", "vase"]
        else:
            categories = ["hydrant"]

        return CO3DDataset(
            root=None,
            num_context=config.num_context,
            num_target=config.num_target,
            stage=config.stage,
            scale_aug_ratio=config.scale_aug_ratio,
            image_size=config.image_size,
            categories=categories,
            noise=config.noise,
        )
    elif name == "Vimeo":
        paths = get_path(name)
        return VimeoDataset(
            root=paths[cluster],
            stage=config.stage,
            image_size=config.image_size,
            # overfit_to_index=config.dataset.overfit_to_index,
        )

    raise NotImplementedError(f'Dataset "{name}" not supported.')
