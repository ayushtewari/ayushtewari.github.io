from pathlib import Path
from typing import List, Tuple, Optional, Union
from random import choice

import numpy as np
import torch
from torch.utils.data import Dataset
from torchvision import transforms as tf
import cv2
from typeguard import typechecked

from geometry import get_opencv_pixel_coordinates
from utils import *
import torch.nn.functional as F

from einops import rearrange
from functools import lru_cache

try:
    pass
except ImportError:
    pass
import os

# Stage = Literal["tain", "test", "val"]


class SRNDataset(Dataset):
    root: Path
    stage: str
    examples: List[Tuple[str, str]]

    z_near: float
    z_far: float
    lindisp: bool = False
    overfit_to_index: Optional[int]
    num_context: int
    num_target: int
    background_color: torch.tensor = torch.tensor([1.0, 1.0, 1.0], dtype=torch.float32)
    image_size: int = 64

    @typechecked
    def __init__(
        self,
        near: float,
        far: float,
        root: Union[str, Path] = Path("datasets/NMR"),
        stage: str = "train",
        list_prefix: str = "",
        num_context: int = 1,
        num_target: int = 2,
        overfit_to_index: Optional[int] = None,
    ) -> None:
        super().__init__()
        self.stage = stage
        # self.root = Path(root)
        self.overfit_to_index = overfit_to_index
        self.num_context = num_context
        self.num_target = num_target

        self.z_near = near
        self.z_far = far

        # Load the image and linearly remap to range [-1, 1].
        self.to_tensor = tf.ToTensor()

        self.root = Path(os.path.join(root, stage))
        # Map category IDs to lists of object IDs.
        self.examples = [path for path in self.root.iterdir() if path.is_dir()]
        self.normalize = normalize_to_neg_one_to_one

        image = self.to_tensor(
            cv2.imread(str(self.get_image_paths(self.examples[0])[0]))
        )
        _, h, w = image.shape
        self.xy_pix = get_opencv_pixel_coordinates(w, h)
        self.xy_pix = rearrange(self.xy_pix, "h w (b c) -> b c h w", b=1)
        self.xy_pix = F.interpolate(
            self.xy_pix, size=(self.image_size, self.image_size), mode="nearest",
        )
        self.xy_pix = rearrange(self.xy_pix, "b c h w -> h w (b c)")

    #
    @typechecked
    def get_image_paths(self, example: Path) -> List[Path]:
        """Retrieve image paths for a single training example."""
        example_root = example
        return [
            path
            for path in sorted((example_root / "rgb").iterdir())
            if path.suffix == ".png"
        ]

    @typechecked
    def read_image(self, image_path: Path):
        """Read an image with its associated camera metadata."""
        raw_image = cv2.imread(str(image_path))
        # resize to 64x64
        raw_image = cv2.resize(
            raw_image,
            (self.image_size, self.image_size),
            interpolation=cv2.INTER_NEAREST,
        )
        image = self.to_tensor(raw_image)

        extrinsic_file = (
            image_path.parents[1] / "pose" / image_path.name.replace(".png", ".txt")
        )
        extrinsics = np.loadtxt(extrinsic_file)
        # print(extrinsics)
        # Read the intrinsics, which are resolution-independent.
        intrinsics_file = open(image_path.parents[1] / "intrinsics.txt")
        f, cx, cy, _ = [float(x) for x in intrinsics_file.readline().split()]
        assert np.allclose(cx, cy)
        c = 0.5
        f = f * c / cx
        intrinsics = torch.tensor(
            [[f, 0, c], [0, f, c], [0, 0, 1]], dtype=torch.float32
        ).view(3, 3)
        # print("intrinsics", intrinsics)
        # intrinsics = (
        #     self.intrinsics
        # )  # np.loadtxt(image_path.parents[1] / "intrinsics.txt").reshape(3, 3)

        # print("intrinsics", intrinsics)
        extrinsics = torch.tensor(extrinsics, dtype=torch.float32).view(4, 4)
        # intrinsics = torch.tensor(intrinsics, dtype=torch.float32).view(3, 3)

        return {
            "image": image,
            "extrinsics_c2w": extrinsics,
            "intrinsics": intrinsics,
        }

    def read_images(self, image_paths: List[Path]):
        """Read a list of images with their associated camera metadata."""
        images = []
        for image_path in image_paths:
            images.append(self.read_image(image_path))
        return images

    @typechecked
    def __len__(self) -> int:
        return len(self.examples)

    @lru_cache(maxsize=None)
    def __getitem__(self, index: int):
        # Use the index to select the positive example.
        rendered_object = self.examples[
            index if self.overfit_to_index is None else self.overfit_to_index
        ]

        # Randomly pick a (different) negative example.
        other_object = rendered_object
        while other_object == rendered_object:
            other_object = choice(self.examples)

        # Fetch the number of images in the rendered and other example.
        image_paths_rendered = self.get_image_paths(rendered_object)

        target_image_paths = np.random.choice(
            image_paths_rendered, self.num_target, replace=False
        )
        rendered = self.read_images(target_image_paths)

        context = self.read_image(
            choice(image_paths_rendered)
            if self.overfit_to_index is None
            else image_paths_rendered[0]
        )
        _, h, w = context["image"].shape

        ctxt_c2w = context["extrinsics_c2w"]
        trgt_c2w = [r["extrinsics_c2w"] for r in rendered]
        trgt_c2w = torch.stack(trgt_c2w)

        # print(f"ctxt_c2w.shape: {ctxt_c2w.shape}, trgt_c2w.shape: {trgt_c2w.shape}")
        inv_ctxt_c2w = torch.inverse(ctxt_c2w)

        ctxt_rgb = self.normalize(context["image"])  # * 2 - 1,
        # trgt_rgb = [self.normalize(r["image"][:, 8:-8, 8:-8]) for r in rendered]
        trgt_rgb = [self.normalize(r["image"]) for r in rendered]
        trgt_rgb = torch.stack(trgt_rgb)

        inv_ctxt_c2w_repeat = inv_ctxt_c2w.unsqueeze(0).repeat(trgt_rgb.shape[0], 1, 1)
        return (
            {
                "ctxt_c2w": torch.einsum("ij, jk -> ik", inv_ctxt_c2w, ctxt_c2w),
                "inv_ctxt_c2w": inv_ctxt_c2w,
                "trgt_c2w": torch.einsum(
                    "ijk, ikl -> ijl", inv_ctxt_c2w_repeat, trgt_c2w
                ),
                "ctxt_rgb": ctxt_rgb,
                "trgt_rgb": trgt_rgb,
                "intrinsics": context["intrinsics"],
                "x_pix": rearrange(self.xy_pix, "h w c -> (h w) c"),
                "idx": torch.tensor([index]),
                "image_shape": torch.tensor([h, w, 3]),
            },
            trgt_rgb,  # rearrange(rendered["image"], "c h w -> (h w) c"),
        )
