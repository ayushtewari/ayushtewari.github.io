from functools import lru_cache
from pathlib import Path
from typing import List, Optional, Tuple, Union

import numpy as np
import torch
import torch.nn.functional as F
import torchvision.transforms as tf
from einops import rearrange, repeat
from torch.utils.data import Dataset
from numpy.random import default_rng
from utils import *
from geometry import get_opencv_pixel_coordinates
from numpy import random
import scipy
import cv2
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
from sklearn.datasets import make_swiss_roll
import sys
import os
from scipy.stats import ortho_group

sys.path.insert(0, os.path.abspath("../"))
import torch

try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal


Stage = Literal["train", "test", "val"]
import os


def sample_batch(size, noise=0.3):
    x, _ = make_swiss_roll(size, noise=noise)
    return x[:, [0, 2]] / 10.0


# Example usage
class SwissRollDataset(Dataset):
    examples: List[Path]
    pose_root: Path
    stage: Stage
    to_tensor: tf.ToTensor
    overfit_to_index: Optional[int]
    num_target: int
    context_min_distance: int
    context_max_distance: int

    z_near: float = 0.1
    z_far: float = 10.0
    image_size: int = 64
    background_color: torch.tensor = torch.tensor([1.0, 1.0, 1.0], dtype=torch.float32)

    def __init__(self, num_target: int, num_context: int,) -> None:
        super().__init__()
        self.num_target = num_target
        self.num_context = num_context
        self.data = sample_batch(10 ** 4).T

    def __len__(self) -> int:
        return self.data.shape[1]

    def __getitem__(self, index: int):

        z = self.data[:, index]
        # randomMatrix = np.random.rand(2, 2)
        randomMatrix = ortho_group.rvs(dim=2)
        # set the first row to [1, 0]
        # randomMatrix[0, 0] = 1.0
        # randomMatrix[0, 1] = 0.0

        # randomMatrix[1, 0] = 0.0
        # randomMatrix[1, 1] = 1.0
        x = randomMatrix @ z
        context = x[None, 0:1]
        target = x[None, 1:2]

        return (
            {
                "ctxt_rgb": torch.tensor(context, dtype=torch.float32),
                "trgt_rgb": torch.tensor(target, dtype=torch.float32),
                "matrix": torch.tensor(randomMatrix, dtype=torch.float32),
                "idx": torch.tensor([index]),
                "z": torch.tensor(z, dtype=torch.float32),
            },
            0,  # rearrange(rendered["image"], "c h w -> (h w) c"),
        )
