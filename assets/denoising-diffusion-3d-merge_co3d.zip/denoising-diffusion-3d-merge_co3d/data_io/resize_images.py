import os

import cv2

root = "/nobackup/users/yilundu/my_repos/dataset/data1024x1024"
out_root = "/nobackup/users/ayusht/datasets/celeba64x64"


def resize(i):
    img = cv2.imread(os.path.join(root, i))
    img = cv2.resize(img, (64, 64))
    cv2.imwrite(os.path.join(out_root, i), img)
    return


import multiprocessing

pool = multiprocessing.Pool(32)
pool.map(resize, [x for x in os.listdir(root) if x.endswith(".jpg")])
