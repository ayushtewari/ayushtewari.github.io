from functools import lru_cache
from pathlib import Path
from typing import List, Optional, Tuple, Union

import numpy as np
import torch
import torch.nn.functional as F
import torchvision.transforms as tf
from einops import rearrange, repeat
from torch.utils.data import Dataset
from numpy.random import default_rng
from utils import *
from geometry import get_opencv_pixel_coordinates
from numpy import random
import scipy
import cv2
from PIL import Image
import torchvision

try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal


Stage = Literal["train", "test", "val"]
import os


def list_folders(path, stage="train"):
    # read list of folders line by line
    with open(os.path.join(path, f"tri_{stage}list.txt")) as f:
        lines = f.readlines()
    # remove whitespace characters like `\n` at the end of each line
    lines = [line.strip() for line in lines]
    # print(lines)
    for i in range(len(lines)):
        dir = os.path.join(path, "sequences", lines[i])
        lines[i] = dir
    return lines


# Example usage
class VimeoDataset(Dataset):
    examples: List[Path]
    pose_root: Path
    stage: Stage
    to_tensor: tf.ToTensor
    overfit_to_index: Optional[int]

    z_near: float = 0.1
    z_far: float = 10.0
    image_size: int = 64
    background_color: torch.tensor = torch.tensor([1.0, 1.0, 1.0], dtype=torch.float32)

    def __init__(
        self,
        root: Union[str, Path],
        stage: Stage = "train",
        overfit_to_index: Optional[int] = None,
        image_size: int = 64,
    ) -> None:
        super().__init__()
        self.overfit_to_index = overfit_to_index
        self.image_size = image_size
        # Ensure that all data loaders use the same image when overfitting.
        if overfit_to_index is not None:
            stage = "train"

        self.examples = list_folders(root, stage=stage)
        self.to_tensor = tf.ToTensor()
        self.rng = default_rng()
        self.normalize = normalize_to_neg_one_to_one
        self.xy_pix = get_opencv_pixel_coordinates(
            x_resolution=self.image_size, y_resolution=self.image_size
        )
        self.transforms = torchvision.transforms.Compose(
            [
                torchvision.transforms.ColorJitter(hue=0.05, saturation=0.05),
                torchvision.transforms.RandomResizedCrop(
                    size=(self.image_size, self.image_size)
                ),
                torchvision.transforms.RandomHorizontalFlip(),
                # torchvision.transforms.GaussianBlur(kernel_size=(5, 9), sigma=(0.1, 3)),
                # torchvision.transforms.RandomRotation(20, resample=Image.BILINEAR),
            ]
        )

    def __len__(self) -> int:
        return len(self.examples)

    def read_image(self, rgb_file):
        rgb_file = rgb_file
        rgb = (
            torch.tensor(np.asarray(Image.open(rgb_file)).astype(np.float32)).permute(
                2, 0, 1
            )
            / 255.0
        )
        # print(rgb.shape, "SHAPE")
        # rgb = F.interpolate(
        #     rgb.unsqueeze(0),
        #     size=(self.image_size, self.image_size),
        #     mode="bilinear",
        #     antialias=True,
        # )[0]

        return rgb

    def __getitem__(self, index: int):
        if self.overfit_to_index is not None:
            index = self.overfit_to_index

        # randomly sample index
        # index = random.randint(0, len(self.examples) - 1)
        # index = len(self.examples) - 1 - index

        def fallback():
            """Used if the desired index can't be loaded."""
            return self[random.randint(0, len(self.examples) - 1)]

        # Retrieve a sorted (by time) list of frames.
        example = self.examples[index]

        # sort the target indices decreasingly
        trgt_rgbs = []
        for i in [3, 2]:
            rgb = self.read_image(os.path.join(example, f"im{i}.png"))
            trgt_rgbs.append(rgb)
            trgt_rgb = torch.stack(trgt_rgbs, axis=0)

        # load the ctxt
        ctxt_rgbs = []
        rgb = self.read_image(os.path.join(example, f"im1.png"))
        ctxt_rgbs.append(rgb)
        ctxt_rgb = torch.stack(ctxt_rgbs, axis=0)

        all_rgb = torch.cat([ctxt_rgb, trgt_rgb], axis=0)
        all_rgb = self.transforms(all_rgb)
        ctxt_rgb = all_rgb[:1]
        trgt_rgb = all_rgb[1:]

        return (
            {
                "ctxt_rgb": self.normalize(ctxt_rgb),
                "ctxt_rgb_nonzero": self.normalize(ctxt_rgb),
                "trgt_rgb": self.normalize(trgt_rgb),
                "x_pix": rearrange(self.xy_pix, "h w c -> (h w) c"),
                "idx": torch.tensor([index]),
                "image_shape": torch.tensor([self.image_size, self.image_size, 3]),
            },
            trgt_rgb,  # rearrange(rendered["image"], "c h w -> (h w) c"),
        )

    def data_for_video(self, video_idx, ctxt_idx, trgt_idx):
        scene_idx = video_idx
        example = self.examples[scene_idx]
        # list all the files in the folder ending with jpg or png
        rgb_files = [
            os.path.join(example, f)
            for f in os.listdir(example)
            if f.endswith(".jpg") or f.endswith(".png")
        ]
        # frame_names = list(example)
        rgb_files = sorted(
            rgb_files, key=lambda x: int(x.split("/")[-1].split(".")[0][6:])
        )

        trgt_rgbs = []
        for id in trgt_idx:
            id = min(id, len(rgb_files) - 1)
            rgb = self.read_image(rgb_files, id)
            trgt_rgbs.append(rgb)
        trgt_rgb = torch.stack(trgt_rgbs, axis=0)

        # load the ctxt
        ctxt_rgbs = []
        for id in ctxt_idx:
            id = min(id, len(rgb_files) - 1)
            rgb = self.read_image(rgb_files, id)
            ctxt_rgbs.append(rgb)
        ctxt_rgb = torch.stack(ctxt_rgbs, axis=0)

        return (
            {
                "ctxt_rgb": self.normalize(ctxt_rgb),
                "ctxt_rgb_nonzero": self.normalize(ctxt_rgb),
                "trgt_rgb": self.normalize(trgt_rgb),
                "x_pix": rearrange(self.xy_pix, "h w c -> (h w) c"),
                "image_shape": torch.tensor([self.image_size, self.image_size, 3]),
            },
            trgt_rgb,  # rearrange(rendered["image"], "c h w -> (h w) c"),
        )
