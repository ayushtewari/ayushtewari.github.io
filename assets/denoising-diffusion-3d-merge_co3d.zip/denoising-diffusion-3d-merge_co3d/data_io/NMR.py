from pathlib import Path
from typing import List, Tuple, Optional, Union
from random import choice

import numpy as np
import torch
from torch.utils.data import Dataset
from torchvision import transforms as tf
import cv2
from typeguard import typechecked
from einops import rearrange

from geometry import get_opencv_pixel_coordinates
from torchvision import transforms as T, utils
from torch import nn
import random
from utils import *
import torch.nn.functional as F
from PIL import Image, ImageFile

try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal


Stage = Literal["train", "test", "val"]


class NMRDataset(Dataset):
    root: Path
    stage: Stage
    examples: List[Tuple[str, str]]

    # The stuff below is legacy pixelNeRF stuff.
    z_near: float = 1.2
    z_far: float = 4.0
    lindisp: bool = False
    overfit_to_index: Optional[int]
    num_context: int
    num_target: int
    # background_color: torch.tensor = torch.tensor([0.0, 0.0, 0.0], dtype=torch.float32)
    background_color: torch.tensor = torch.tensor([1.0, 1.0, 1.0], dtype=torch.float32)
    image_size: int = 64
    border: int = 8

    @typechecked
    def __init__(
        self,
        root: Union[str, Path] = Path("datasets/NMR"),
        stage: Stage = "train",
        list_prefix: str = "",
        num_context: int = 1,
        num_target: int = 2,
        overfit_to_index: Optional[int] = None,
    ) -> None:
        super().__init__()
        self.stage = stage
        self.root = Path(root)
        self.overfit_to_index = overfit_to_index
        self.max_num_context = num_context
        self.num_target = num_target

        # Load the image and linearly remap to range [-1, 1].
        self.to_tensor = tf.ToTensor()

        # Map category IDs to lists of object IDs.
        self.examples = []
        list_name = f"{list_prefix}{stage}.lst"
        categories = [path for path in self.root.iterdir() if path.is_dir()]
        for category in categories:
            with (category / list_name).open("r") as f:
                ids = [id.strip() for id in f.readlines()]
            for id in ids:
                self.examples.append((category.name, id))
        self.normalize = normalize_to_neg_one_to_one
        self.xy_pix = get_opencv_pixel_coordinates(
            x_resolution=self.image_size, y_resolution=self.image_size
        )

    @typechecked
    def get_image_paths(self, example: Tuple[str, str]) -> List[Path]:
        """Retrieve image paths for a single training example."""
        category, id = example
        example_root = self.root / category / id
        return [
            path
            for path in sorted((example_root / "image").iterdir())
            if path.suffix == ".png"
        ]

    @typechecked
    def read_image(self, image_path: Path):
        """Read an image with its associated camera metadata."""
        # raw_image = cv2.imread(str(image_path))
        image = (
            torch.tensor(
                np.asarray(Image.open(image_path)).astype(np.float32)
                # [
                #     self.border : -self.border, self.border : -self.border, :
                # ]
            ).permute(2, 0, 1)
            / 255.0
        )
        image = F.interpolate(
            image.unsqueeze(0),
            size=(self.image_size, self.image_size),
            mode="bilinear",
        )[0]

        mask = cv2.imread(str(image_path.parents[1] / "mask" / image_path.name))
        mask = torch.tensor(mask.mean(axis=-1), dtype=torch.bool)
        # image = self.to_tensor(raw_image)
        # set image outside mask to background color
        # image[:, ~mask] = self.background_color[:, None]

        # Generate bounding boxes.
        rows = torch.where(~mask.all(dim=0))[0]
        cols = torch.where(~mask.all(dim=1))[0]
        bounds = torch.stack([cols.min(), rows.min(), cols.max(), rows.max()])

        # Read the pose, which is in OpenCV-style C2W format.
        cameras = np.load(image_path.parents[1] / "cameras.npz")
        extrinsics = torch.tensor(
            cameras[f"world_mat_inv_{int(image_path.stem)}"], dtype=torch.float32
        )

        # Read the intrinsics, which are resolution-independent.
        intrinsics = cameras[f"camera_mat_{int(image_path.stem)}"]
        fx, fy = intrinsics[0, 0], intrinsics[1, 1]
        assert np.allclose(fx, fy)
        c, h, w = image.shape
        assert np.allclose(h, w)
        c = 0.5
        f = fx * c
        intrinsics = torch.tensor(
            [[f, 0, c], [0, f, c], [0, 0, 1]], dtype=torch.float32
        )

        return {
            "image": image,
            "mask": mask,
            "extrinsics_c2w": extrinsics,
            "intrinsics": intrinsics,
            "bounding_box_2d": bounds,
        }

    def read_images(self, image_paths: List[Path]):
        """Read a list of images with their associated camera metadata."""
        images = []
        for image_path in image_paths:
            images.append(self.read_image(image_path))
        return images

    @typechecked
    def __len__(self) -> int:
        return len(self.examples)

    @typechecked
    def __getitem__(self, index: int):
        # Use the index to select the positive example.
        rendered_object = self.examples[
            index if self.overfit_to_index is None else self.overfit_to_index
        ]

        # Randomly pick a (different) negative example.
        other_object = rendered_object
        while other_object == rendered_object:
            other_object = choice(self.examples)

        # Fetch the number of images in the rendered and other example.
        image_paths_rendered = self.get_image_paths(rendered_object)

        # target_image_paths = np.random.choice(
        #     image_paths_rendered, self.num_target, replace=False
        # )
        # rendered = self.read_images(target_image_paths)

        num_context = self.max_num_context
        image_paths = np.random.choice(
            image_paths_rendered, self.num_target + num_context, replace=False
        )
        target_image_paths = image_paths[: self.num_target]
        context_image_paths = image_paths[self.num_target :]
        rendered = self.read_images(target_image_paths)
        context = self.read_images(context_image_paths)

        _, h, w = context[0]["image"].shape

        trgt_c2w = [r["extrinsics_c2w"] for r in rendered]
        trgt_c2w = torch.stack(trgt_c2w)

        ctxt_c2w = [r["extrinsics_c2w"] for r in context]
        ctxt_c2w = torch.stack(ctxt_c2w)

        inv_ctxt_c2w = torch.inverse(ctxt_c2w[0])

        trgt_rgb = [self.normalize(r["image"]) for r in rendered]
        trgt_rgb = torch.stack(trgt_rgb)
        ctxt_rgb = [self.normalize(r["image"]) for r in context]
        ctxt_rgb = torch.stack(ctxt_rgb)

        inv_ctxt_c2w_repeat = inv_ctxt_c2w.unsqueeze(0).repeat(trgt_rgb.shape[0], 1, 1)
        ctxt_inv_ctxt_c2w_repeat = inv_ctxt_c2w.unsqueeze(0).repeat(
            ctxt_rgb.shape[0], 1, 1
        )
        # print(
        #     f"ctxt_rgb.shape {ctxt_rgb.shape}, trgt_rgb.shape {trgt_rgb.shape}, trgt_c2w.shape {trgt_c2w.shape}, ctxt_c2w.shape {ctxt_c2w.shape}, inv_ctxt_c2w_repeat.shape {inv_ctxt_c2w_repeat.shape}, ctxt_inv_ctxt_c2w_repeat.shape {ctxt_inv_ctxt_c2w_repeat.shape}, intrinsics.shape {context[0]['intrinsics'].shape}, self.xy_pix.shape {self.xy_pix.shape}"
        # )
        return (
            {
                "ctxt_c2w": torch.einsum(
                    "ijk, ikl -> ijl", ctxt_inv_ctxt_c2w_repeat, ctxt_c2w
                ),
                "trgt_c2w": torch.einsum(
                    "ijk, ikl -> ijl", inv_ctxt_c2w_repeat, trgt_c2w
                ),
                "inv_ctxt_c2w": ctxt_inv_ctxt_c2w_repeat,
                "ctxt_rgb": ctxt_rgb,
                "trgt_rgb": trgt_rgb,
                "intrinsics": context[0]["intrinsics"],
                "x_pix": rearrange(self.xy_pix, "h w c -> (h w) c"),
                "image_shape": torch.tensor([h, w, 3]),
                "idx": torch.tensor([index]),
            },
            rearrange(trgt_rgb[0], "c h w -> (h w) c"),
        )

    def data_for_video(self, video_idx, ctxt_idx, trgt_idx):
        # index = random.randint(0, len(self.examples) - 1)
        index = video_idx
        # print("ignoring video_idx")
        rendered_object = self.examples[index]
        image_paths_rendered = self.get_image_paths(rendered_object)

        print(f"trgt_idx {trgt_idx} ctxt_idx {ctxt_idx}")
        target_image_paths = [image_paths_rendered[i] for i in trgt_idx]
        context_image_paths = [image_paths_rendered[i] for i in ctxt_idx]

        rendered = self.read_images(target_image_paths)
        context = self.read_images(context_image_paths)

        _, h, w = context[0]["image"].shape

        trgt_c2w = [r["extrinsics_c2w"] for r in rendered]
        trgt_c2w = torch.stack(trgt_c2w)

        ctxt_c2w = [r["extrinsics_c2w"] for r in context]
        ctxt_c2w = torch.stack(ctxt_c2w)

        inv_ctxt_c2w = torch.inverse(ctxt_c2w[0])

        trgt_rgb = [self.normalize(r["image"]) for r in rendered]
        trgt_rgb = torch.stack(trgt_rgb)
        ctxt_rgb = [self.normalize(r["image"]) for r in context]
        ctxt_rgb = torch.stack(ctxt_rgb)

        inv_ctxt_c2w_repeat = inv_ctxt_c2w.unsqueeze(0).repeat(trgt_rgb.shape[0], 1, 1)
        ctxt_inv_ctxt_c2w_repeat = inv_ctxt_c2w.unsqueeze(0).repeat(
            ctxt_rgb.shape[0], 1, 1
        )
        return (
            {
                "ctxt_c2w": torch.einsum(
                    "ijk, ikl -> ijl", ctxt_inv_ctxt_c2w_repeat, ctxt_c2w
                ),
                "trgt_c2w": torch.einsum(
                    "ijk, ikl -> ijl", inv_ctxt_c2w_repeat, trgt_c2w
                ),
                "inv_ctxt_c2w": ctxt_inv_ctxt_c2w_repeat,
                "ctxt_rgb": ctxt_rgb,
                "trgt_rgb": trgt_rgb,
                "intrinsics": context[0]["intrinsics"],
                "x_pix": rearrange(self.xy_pix, "h w c -> (h w) c"),
                "image_shape": torch.tensor([h, w, 3]),
                "idx": torch.tensor([index]),
            },
            None,  # rearrange(rendered["image"], "c h w -> (h w) c"),
        )


class NMRImagesDataset(Dataset):
    root: Path
    stage: Stage
    examples: List[Tuple[str, str]]

    @typechecked
    def __init__(
        self,
        root: Union[str, Path] = Path("datasets/NMR"),
        stage: Stage = "train",
        image_size: int = 64,
        augment_horizontal_flip: bool = True,
        list_prefix: str = "",
        overfit_to_index: Optional[int] = None,
    ) -> None:
        super().__init__()
        self.stage = stage
        self.root = Path(root)
        self.overfit_to_index = overfit_to_index

        # Load the image and linearly remap to range [-1, 1].
        self.to_tensor = tf.ToTensor()

        # Map category IDs to lists of object IDs.
        self.examples = []
        list_name = f"{list_prefix}{stage}.lst"
        categories = [path for path in self.root.iterdir() if path.is_dir()]
        for category in categories:
            with (category / list_name).open("r") as f:
                ids = [id.strip() for id in f.readlines()]
            for id in ids:
                self.examples.append((category.name, id))

        self.transform = T.Compose(
            [
                T.Resize(image_size),
                # T.RandomHorizontalFlip() if augment_horizontal_flip else nn.Identity(),
                T.CenterCrop(image_size),
                # T.ToTensor(),
            ]
        )

    @typechecked
    def get_image_paths(self, example: Tuple[str, str]) -> List[Path]:
        """Retrieve image paths for a single training example."""
        category, id = example
        example_root = self.root / category / id
        return [
            path
            for path in sorted((example_root / "image").iterdir())
            if path.suffix == ".png"
        ]

    @typechecked
    def read_image(self, image_path: Path):
        """Read an image with its associated camera metadata."""
        raw_image = cv2.imread(str(image_path))
        mask = cv2.imread(str(image_path.parents[1] / "mask" / image_path.name))
        mask = torch.tensor(mask.mean(axis=-1), dtype=torch.bool)
        image = self.to_tensor(raw_image)

        # Generate bounding boxes.
        rows = torch.where(~mask.all(dim=0))[0]
        cols = torch.where(~mask.all(dim=1))[0]
        bounds = torch.stack([cols.min(), rows.min(), cols.max(), rows.max()])

        # Read the pose, which is in OpenCV-style C2W format.
        cameras = np.load(image_path.parents[1] / "cameras.npz")
        extrinsics = torch.tensor(
            cameras[f"world_mat_inv_{int(image_path.stem)}"], dtype=torch.float32
        )

        # Read the intrinsics, which are resolution-independent.
        intrinsics = cameras[f"camera_mat_{int(image_path.stem)}"]
        fx, fy = intrinsics[0, 0], intrinsics[1, 1]
        assert np.allclose(fx, fy)
        c, h, w = image.shape
        assert np.allclose(h, w)
        c = 0.5
        f = fx * c
        intrinsics = torch.tensor(
            [[f, 0, c], [0, f, c], [0, 0, 1]], dtype=torch.float32
        )

        return {
            "image": image,
            "mask": mask,
            "extrinsics_c2w": extrinsics,
            "intrinsics": intrinsics,
            "bounding_box_2d": bounds,
        }

    @typechecked
    def __len__(self) -> int:
        return len(self.examples)

    @typechecked
    def __getitem__(self, index: int):
        # idx = random.randint(0, len(self.examples) - 1)
        # Use the index to select the positive example.
        rendered_object = self.examples[index]

        # Fetch the number of images in the rendered and other example.
        image_paths_rendered = self.get_image_paths(rendered_object)

        # im_idx = random.randint(0, len(image_paths_rendered) - 1)
        im_idx = 0
        context = self.read_image(image_paths_rendered[im_idx])
        rgb = self.transform(context["image"])
        return (
            {"ctxt_rgb": rgb[:, 8:-8, 8:-8], "trgt_rgb": rgb[:, 8:-8, 8:-8]},
            rgb[:, 8:-8, 8:-8],
        )
