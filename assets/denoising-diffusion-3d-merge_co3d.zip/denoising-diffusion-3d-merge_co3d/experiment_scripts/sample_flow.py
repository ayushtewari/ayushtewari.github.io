import sys
import os
import wandb
import hydra
from omegaconf import DictConfig
from torch.utils.data import Dataset, DataLoader

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from denoising_diffusion_pytorch.denoising_flow import (
    GaussianDiffusion,
    Trainer,
)
import data_io

# from PixelNeRF import PixelNeRFModel, PixelNeRFImageModel
from Flow import FlowModel
import torch
import imageio
import numpy as np
from utils import *
from torchvision.utils import make_grid
from numpy import random
import flow_vis


@hydra.main(
    version_base=None, config_path="../configurations/", config_name="config",
)
def train(cfg: DictConfig):
    # run = wandb.init(**cfg.wandb)
    # wandb.run.log_code(".")
    # wandb.run.name = cfg.name
    # print(f"run dir: {run.dir}")
    # run_dir = run.dir
    # wandb.save(os.path.join(run_dir, "checkpoint*"))
    # wandb.save(os.path.join(run_dir, "video*"))

    run = wandb.init(**cfg.wandb)
    wandb.run.log_code(".")
    wandb.run.name = cfg.name
    print(f"run dir: {run.dir}")
    run_dir = run.dir
    wandb.save(os.path.join(run_dir, "checkpoint*"))
    wandb.save(os.path.join(run_dir, "video*"))

    # dataset
    train_batch_size = cfg.batch_size
    dataset = data_io.get_dataset(cfg)
    dataset.num_context = 1
    dl = DataLoader(
        dataset,
        batch_size=train_batch_size,
        shuffle=False,
        pin_memory=True,
        num_workers=0,
    )

    model = FlowModel(
        model=cfg.model_type,
        viz_type=cfg.dataset.viz_type,
        use_first_pool=cfg.use_first_pool,
        feats_cond=cfg.feats_cond,
        use_high_res_feats=True,
        use_viewdir=False,
    ).cuda()
    # model = PixelNeRFImageModel(
    #     near=1.2, far=4.0, dim=64, dim_mults=(1, 1, 2, 4)
    # ).cuda()
    # model = Unet(dim=64, dim_mults=(2, 4, 8)).cuda()

    diffusion = GaussianDiffusion(
        model,
        image_size=dataset.image_size,
        timesteps=1000,  # number of steps
        sampling_timesteps=250,
        loss_type="l2",  # L1 or L2
        objective="pred_x0",
        beta_schedule="cosine",
    ).cuda()

    print(f"using lr {cfg.lr}")
    trainer = Trainer(
        diffusion,
        dataloader=dl,
        train_batch_size=train_batch_size,
        train_lr=cfg.lr,
        train_num_steps=700000,  # total training steps
        gradient_accumulate_every=1,  # gradient accumulation steps
        ema_decay=0.995,  # exponential moving average decay
        amp=False,  # turn on mixed precision
        sample_every=1000,
        wandb_every=500,
        save_every=5000,
        num_samples=1,
        warmup_period=1_000,
        checkpoint_path=cfg.checkpoint_path,
        wandb_config=cfg.wandb,
        run_name=cfg.name,
    )
    # trainer.sample(num_ctxt=100, num_samples_per_ctxt=5)
    # # # #
    # ctxt_idx = [0]
    sampling_type = cfg.sampling_type
    use_dataset_pose = True
    np.random.seed(10)
    video_idx = random.randint(0, len(dataset) - 1)
    video_idx = random.randint(0, len(dataset) - 1)
    if sampling_type == "simple":
        with torch.no_grad():
            for _ in range(1000):
                # step = 10
                video_idx = random.randint(0, len(dataset) - 1)
                print(f"video_idx: {video_idx}, len: {len(dataset)}")
                for i in range(1):
                    # end_idx = random.randint(0, 50)
                    end_idx = 90  # random.randint(30, 90)
                    start_idx = 0  # i * step
                    # flip start and end idx to get reverse direction randomly
                    if np.random.rand() > 0.5:
                        start_idx, end_idx = end_idx, start_idx

                    # start_idx = 14
                    # end_idx = 35
                    ctxt_idx = [start_idx]  # [i * step]
                    trgt_idx = np.array([end_idx], dtype=np.int64)

                    ctxt_idx_np = np.array(ctxt_idx, dtype=np.int64)
                    trgt_idx_np = np.array(trgt_idx, dtype=np.int64)

                    print(f"Starting rendering step {ctxt_idx_np}, {trgt_idx_np}")
                    data = dataset.data_for_video(
                        video_idx=video_idx + i,
                        ctxt_idx=ctxt_idx_np,
                        trgt_idx=trgt_idx_np,
                    )
                    inp = to_gpu(data[0], "cuda")
                    for k in inp.keys():
                        inp[k] = inp[k].unsqueeze(0)

                    if not use_dataset_pose:
                        poses = trainer.model.model.compute_poses("spherical", inp, 20)
                        print(f"poses shape: {poses.shape}")
                        inp["render_poses"] = poses
                        inp["trgt_c2w"] = poses[-1].unsqueeze(0).unsqueeze(0).cuda()

                    print(f"len of idx: {len(ctxt_idx)}")
                    for j in range(2):
                        print(f"Starting sample {j}")
                        # out = trainer.model.sample(batch_size=1, inp=inp)
                        out = trainer.ema.ema_model.sample(batch_size=1, inp=inp)
                        """
                        frames = out["videos"]
                        depth_frames = out["depth_videos"]

                        depth = torch.cat(depth_frames, dim=0)
                        depth = (
                            torch.from_numpy(
                                jet_depth(depth[:].cpu().detach().view(-1, 64, 64))
                            )
                            * 255
                        )
                        # convert depth to list of images
                        depth_frames = []
                        for i in range(depth.shape[0]):
                            depth_frames.append(
                                depth[i].cpu().detach().numpy().astype(np.uint8)
                            )

                        # print(f"depth shape: {depth[0].shape}, {frames[0].shape}")
                        # print(f"depth range: {depth.min()}, {depth.max()}, {depth.mean()}")
                        denoised_f = os.path.join(run_dir, "denoised_view_circle.mp4")
                        imageio.mimwrite(denoised_f, frames, fps=8, quality=7)
                        denoised_f_depth = os.path.join(
                            run_dir, "denoised_view_circle_depth.mp4"
                        )
                        imageio.mimwrite(
                            denoised_f_depth, depth_frames, fps=8, quality=7
                        )
                        # idx = inp["idx"]
                        wandb.log(
                            {
                                "vid/interp": wandb.Video(
                                    denoised_f,
                                    format="mp4",
                                    fps=8,
                                    caption=f"{video_idx}",
                                ),
                                "vid/interp_depth": wandb.Video(
                                    denoised_f_depth, format="mp4", fps=8
                                ),
                            }
                        )
                        """

                        def prepare_flows(flows):
                            new_flows = []
                            for i in range(min(flows.shape[0], 10)):
                                flow = flows[i]
                                flow = flow_vis.flow_to_color(
                                    flow.permute(1, 2, 0).cpu().detach().numpy(),
                                    convert_to_bgr=False,
                                )
                                new_flows.append(flow)
                            new_flows = torch.from_numpy(np.array(new_flows))
                            new_flows = make_grid(new_flows.permute(0, 3, 1, 2))
                            new_flows = new_flows.type(torch.float32) / 255.0
                            new_flows = wandb.Image(new_flows)
                            return new_flows

                        ctxt_img = (
                            trainer.model.unnormalize(inp["ctxt_rgb"][:, 0])
                            .cpu()
                            .detach()
                        )
                        trgt_img = (
                            trainer.model.unnormalize(inp["trgt_rgb"][:, 0])
                            .cpu()
                            .detach()
                        )

                        image_dict = {
                            "result/trgt_rgb": wandb.Image(make_grid(trgt_img)),
                            "result/ctxt_rgb": wandb.Image(make_grid(ctxt_img)),
                            "result/output": wandb.Image(
                                make_grid(
                                    trainer.model.normalize(out["images"])
                                    .cpu()
                                    .detach()
                                )
                                .permute(1, 2, 0)
                                .numpy()
                            ),
                            "result/flow": prepare_flows(out["flow"][:]),
                        }
                        wandb.log(image_dict)


if __name__ == "__main__":
    train()
