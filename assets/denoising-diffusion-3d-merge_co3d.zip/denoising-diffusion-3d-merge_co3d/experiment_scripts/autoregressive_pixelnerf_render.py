import sys
import os
import wandb
import hydra
from omegaconf import DictConfig
from torch.utils.data import Dataset, DataLoader
from utils import *

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import data_io

from denoising_diffusion_pytorch.pixelnerf_trainer import (
    PixelNeRFModelWrapper,
    Trainer,
)

# from PixelNeRF import PixelNeRFModel, PixelNeRFImageModel
from PixelNeRF import PixelNeRFModelCond, PixelNeRFModelVanilla
import imageio


@hydra.main(
    version_base=None, config_path="../configurations/", config_name="config",
)
def train(cfg: DictConfig):
    # setting up wandb
    run = wandb.init(**cfg.wandb)
    wandb.run.log_code(".")
    wandb.run.name = cfg.name
    print(f"run dir: {run.dir}")
    run_dir = run.dir
    wandb.save(os.path.join(run_dir, "checkpoint*"))
    wandb.save(os.path.join(run_dir, "video*"))

    # dataset
    train_batch_size = cfg.batch_size
    dataset = data_io.get_dataset(cfg)
    dl = DataLoader(
        dataset,
        batch_size=train_batch_size,
        shuffle=False,
        pin_memory=True,
        num_workers=0,
    )

    # model_type = "vit"
    # backbone = "vitb_rn50_384"
    # backbone = "vitl16_384"
    # vit_path = get_vit_path(backbone)

    # model_type = "dit"
    model_type = "resnet"
    backbone = None
    vit_path = None
    model = PixelNeRFModelVanilla(
        near=dataset.z_near,
        far=dataset.z_far,
        model=model_type,
        backbone=backbone,
        background_color=dataset.background_color,
        viz_type=cfg.dataset.viz_type,
        use_first_pool=cfg.use_first_pool,
        lindisp=cfg.dataset.lindisp,
        path=vit_path,
    ).cuda()
    modelwrapper = PixelNeRFModelWrapper(
        model, image_size=dataset.image_size, loss_type="l2",  # L1 or L2
    ).cuda()

    print(f"using lr {cfg.lr}")
    trainer = Trainer(
        reconstruction_model=modelwrapper,
        dataloader=dl,
        train_batch_size=train_batch_size,
        train_lr=cfg.lr,
        train_num_steps=700000,  # total training steps
        gradient_accumulate_every=1,  # gradient accumulation steps
        ema_decay=0.995,  # exponential moving average decay
        amp=False,  # turn on mixed precision
        sample_every=1000,
        wandb_every=cfg.wandb_every,
        save_every=1000,
        num_samples=2,
        warmup_period=1_000,
        checkpoint_path=cfg.checkpoint_path,
        wandb_config=cfg.wandb,
        run_name=cfg.name,
    )

    ctxt_idx = [0]
    with torch.no_grad():
        for i in range(20):
            # start_idx = 0
            end_idx = (i + 1) * 5
            # mid_idx = (start_idx + end_idx) // 2
            # ctxt_idx = np.array([start_idx, mid_idx, end_idx], dtype=np.int64)

            ctxt_idx = ctxt_idx + [end_idx]
            ctxt_idx_np = np.array(ctxt_idx, dtype=np.int64)

            print(f"Starting rendering step {ctxt_idx_np}")
            data = dataset.data_for_video(video_idx=0, ctxt_idx=ctxt_idx_np)
            inp = to_gpu(data[0], "cuda")
            # print(inp.keys())
            for k in inp.keys():
                inp[k] = inp[k].unsqueeze(0)
            print(f"len of idx: {len(ctxt_idx)}")
            frames = model.render_video(inp, n=5 * len(ctxt_idx), t=None)

            denoised_f = os.path.join(run_dir, "denoised_view_circle.mp4")
            imageio.mimwrite(denoised_f, frames, fps=8, quality=7)

            wandb.log(
                {"vid/interp": wandb.Video(denoised_f, format="mp4", fps=8),}
            )


if __name__ == "__main__":
    train()
