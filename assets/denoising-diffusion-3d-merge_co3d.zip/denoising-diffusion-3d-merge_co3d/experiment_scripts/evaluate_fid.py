from cleanfid.fid import get_files_features, kernel_distance, frechet_distance, get_folder_features
from cleanfid.features import build_feature_extractor
from tqdm import tqdm 
from PIL import Image
import numpy as np 
import glob 
import torch 
import lpips 
import os 

def compute_fid(feat1, feats2):
    mu1 = np.mean(feat1, axis=0)
    sigma1 = np.cov(feat1, rowvar=False)
    mu2 = np.mean(feats2, axis=0)
    sigma2 = np.cov(feats2, rowvar=False)
    fid = frechet_distance(mu1, sigma1, mu2, sigma2)
    return fid

def compute_statistics(generated_folder, reference_folder, mode="clean", device=torch.device("cuda"), model_name="inception_v3"):
    if model_name=="inception_v3":
        feat_model = build_feature_extractor(mode, device)
    else:
        raise NotImplementedError()

    np_feats_gen = get_folder_features(generated_folder, feat_model, device=device, mode=mode)
    np_feats_ref = get_folder_features(reference_folder, feat_model, device=device, mode=mode)

    kid_score = kernel_distance(np_feats_ref, np_feats_gen)
    fid_score = compute_fid(np_feats_ref, np_feats_gen)

    print(f"fid score {fid_score} kid score {kid_score}")

    generated_images = sorted(glob.glob(os.path.join(generated_folder, "*.png")))
    reference_images = sorted(glob.glob(os.path.join(reference_folder, "*.png")))

    # compute psnr and lpips between each pair of images
    perceptual_loss = lpips.LPIPS(net="vgg").cuda()

    psnr_scores = []
    lpips_scores = []
    for gen_image_path, ref_image_path in tqdm(zip(generated_images, reference_images)):
        # Load images
        gen_image = Image.open(gen_image_path).convert("RGB")
        ref_image = Image.open(ref_image_path).convert("RGB")

        # Convert to numpy arrays
        gen_image_np = np.array(gen_image)
        ref_image_np = np.array(ref_image)

        gen_image_torch = torch.from_numpy(gen_image_np).float() / 255.0
        ref_image_torch = torch.from_numpy(ref_image_np).float() / 255.0
        psnr_loss = 10 * torch.log10( 1 / torch.nn.MSELoss()(gen_image_torch, ref_image_torch)).item() 
        lpips_loss = perceptual_loss(gen_image_torch.permute(2, 0, 1)[None].cuda(), ref_image_torch.permute(2, 0, 1)[None].cuda(), normalize=True).item()
       
        psnr_scores.append(psnr_loss)
        lpips_scores.append(lpips_loss)

    print(f"psnr {np.mean(psnr_scores)} lpips {np.mean(lpips_scores)}")

if __name__ == "__main__":
    import argparse 
    parser = argparse.ArgumentParser()
    parser.add_argument("--generated_folder", type=str, required=True)
    parser.add_argument("--reference_folder", type=str, required=True)
    args = parser.parse_args()

    compute_statistics(args.generated_folder, args.reference_folder)
