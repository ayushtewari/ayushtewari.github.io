import cv2
import numpy as np
from pyntcloud import PyntCloud
import pandas as pd
import torch
import os
from geometry import unproject, homogenize_points

import data_io
from omegaconf import DictConfig
import hydra
import open3d as o3d


def generate_point_cloud(
    xy_pix, rgb_image, depth_map, camera_intrinsics, camera_extrinsics
):
    # Assuming depth_map and rgb_image have the same width and height
    height, width, _ = rgb_image.shape

    # Create a 3D array to hold the colored point cloud data.
    output_points = torch.zeros((height * width, 6))
    point = unproject(xy_pix, depth_map.reshape(-1, 1), intrinsics=camera_intrinsics)
    point = torch.einsum(
        "...ij,...kj->...ki", camera_extrinsics, homogenize_points(point)
    )

    output_points[:, :3] = point[:, :3]
    output_points[:, 3:6] = rgb_image.reshape(-1, 3)

    return output_points.numpy()


@hydra.main(
    version_base=None, config_path="../configurations/", config_name="config",
)
def main(cfg: DictConfig):
    # from data_io.co3d_new import CO3DDataset
    # DS = CO3DDataset(
    #     root="/nobackup/nvme1/CO3Dv2", num_context=3, num_target=2, stage="train"
    # )

    video_idx = 116
    # depth_map_path = "/scratch2/weka/tenenbaum/ayusht/projects/denoising-diffusion-3d/wandb/run-20230603_040935-jyzgwefn/files/generated_frames/video_5"
    depth_map_path = "/scratch2/weka/tenenbaum/ayusht/projects/denoising-diffusion-3d/wandb/run-20230603_220542-90963qvu/files/generated_frames/video_5"
    # depth_map_path = "/scratch2/weka/tenenbaum/ayusht/projects/denoising-diffusion-3d/wandb/run-20230603_232231-r8vngk4t/files/generated_frames/"
    name = "diffusion_5"
    dataset = data_io.get_dataset(cfg)
    # data = DS.data_for_video(video_idx, load_all_frames=True)[0]
    ctxt_idx = [150]  # [i * step]
    trgt_idx = np.array([0], dtype=np.int64)
    ctxt_idx_np = np.array(ctxt_idx, dtype=np.int64)
    trgt_idx_np = np.array(trgt_idx, dtype=np.int64)

    print(f"Starting rendering step {ctxt_idx_np}, {trgt_idx_np}")
    data = dataset.data_for_video(
        video_idx=video_idx, ctxt_idx=ctxt_idx_np, trgt_idx=trgt_idx_np,
    )[0]

    # ctxt_rgb = data["ctxt_rgb"]
    # depth_maps = torch.load(depth_map_path)["depth"]

    intrinsics = data["intrinsics"]
    c2ws = data["render_poses"]
    x_pix = data["x_pix"]

    point_clouds = []

    # for rgb_image, depth_map, c2w in zip(ctxt_rgb, depth_maps, c2ws):
    depth_map_files = sorted(
        [f for f in os.listdir(depth_map_path) if f.endswith(".npy")]
    )
    print(len(depth_map_files))
    print(c2ws.shape)
    for i in range(len(depth_map_files)):
        # print(i)
        # rgb_image = (rgb_image.permute(1, 2, 0) * 0.5 + 0.5) * 255.0
        # depth_map = torch.from_numpy(depth_map)
        rgbd = np.load(os.path.join(depth_map_path, depth_map_files[i]))
        rgbd = torch.from_numpy(rgbd)
        rgb_image = rgbd[:, :, :3]
        depth_map = rgbd[:, :, 3]
        point_cloud = generate_point_cloud(
            x_pix, rgb_image, depth_map, intrinsics, c2ws[i]
        )
        point_clouds.append(point_cloud)

    # # Aggregate all the point clouds
    print(len(point_clouds))
    aggregated_point_cloud = np.vstack(point_clouds)
    # # Create a pandas dataframe
    # df = pd.DataFrame(
    #     aggregated_point_cloud, columns=["x", "y", "z", "red", "green", "blue"]
    # )
    #
    # # Create a PyntCloud object from the dataframe
    # cloud = PyntCloud(df)
    #
    # # Save the point cloud to a file
    # cloud.to_file("debug/point_cloud/output_point_cloud.ply")
    print(aggregated_point_cloud.shape)
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(aggregated_point_cloud[:, :3])
    pcd.colors = o3d.utility.Vector3dVector(aggregated_point_cloud[:, 3:6] / 255.0)
    o3d.io.write_point_cloud(f"debug/point_cloud/{name}.ply", pcd)


if __name__ == "__main__":
    main()
