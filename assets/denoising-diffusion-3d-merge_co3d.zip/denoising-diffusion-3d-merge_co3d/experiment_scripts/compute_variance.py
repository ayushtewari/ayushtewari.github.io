import os
import numpy as np
from PIL import Image
from utils import *
import torch

root = "/Users/atewari/Documents/papers/3d/videos/diversity/files_150"
out_folder = f"{root}/variance_norm"
os.makedirs(out_folder, exist_ok=True)

N = 38

all_images = np.zeros((10, N, 128, 128, 3))

for i in range(10):
    folder = os.path.join(root, f"videos_150_{i}")
    print(folder)
    images = []
    # read all images
    # images[i] = [
    #     Image.open(os.path.join(folder, img))
    #     for img in os.listdir(folder)
    #     if img.endswith(".png")
    # ]
    for j in range(N):
        I = Image.open(os.path.join(folder, f"frame_{j:04d}.png"))
        images.append(I)
        # I.close()
    #
    # images to numpu
    images = np.array([np.array(img) for img in images])
    all_images[i] = images

print(all_images.shape)

# compute variance along the 0th axis
variance = np.var(all_images, axis=0)
#

# compute magnitude of variance
variance = np.linalg.norm(variance, axis=-1)
print(variance.shape)
# variance = variance / variance.max()

jet_variance = jet_depth(torch.from_numpy(variance)) * 255
print(jet_variance.shape, jet_variance.max(), jet_variance.min(), jet_variance.mean())
# variance = variance.astype(np.uint8)


# print(variance.shape, variance.max(), variance.min(), variance.mean())


# save the variance images
for i in range(N):
    variance_image = Image.fromarray(jet_variance[i].astype(np.uint8))
    variance_image.save(f"{out_folder}/{i:04d}.png")
    variance_image.close()
