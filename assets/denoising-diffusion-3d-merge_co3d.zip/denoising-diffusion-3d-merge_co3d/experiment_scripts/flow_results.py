import sys
import os
import wandb
import hydra
from omegaconf import DictConfig
from torch.utils.data import Dataset, DataLoader

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import data_io
from einops import rearrange

# from PixelNeRF import PixelNeRFModel, PixelNeRFImageModel
from PixelNeRF import PixelNeRFModelCond
import torch
import imageio
import numpy as np
from utils import *
from torchvision.utils import make_grid
from accelerate import DistributedDataParallelKwargs
from accelerate import Accelerator
from results_configs import re_indices
import matplotlib.pyplot as plt
import torch.nn.functional as F

from denoising_diffusion_pytorch.denoising_flow import (
    GaussianDiffusion,
    Trainer,
)
from Flow import FlowModel
from Flow.visualize_flow import visualizeFlow
import flow_vis
from PIL import Image


@hydra.main(
    version_base=None, config_path="../configurations/", config_name="config",
)
def train(cfg: DictConfig):
    run = wandb.init(**cfg.wandb)
    wandb.run.log_code(".")
    wandb.run.name = cfg.name
    print(f"run dir: {run.dir}")
    run_dir = run.dir
    wandb.save(os.path.join(run_dir, "checkpoint*"))
    wandb.save(os.path.join(run_dir, "video*"))
    # initialize the accelerator at the beginning
    ddp_kwargs = DistributedDataParallelKwargs(find_unused_parameters=True)
    accelerator = Accelerator(
        split_batches=True, mixed_precision="no", kwargs_handlers=[ddp_kwargs],
    )

    # dataset
    train_batch_size = cfg.batch_size
    dataset = data_io.get_dataset(cfg)
    dl = DataLoader(
        dataset, batch_size=1, shuffle=False, pin_memory=True, num_workers=0,
    )
    torch.manual_seed(17)

    model_type = cfg.model_type
    model = FlowModel(
        model=model_type,
        viz_type=cfg.dataset.viz_type,
        use_first_pool=cfg.use_first_pool,
        feats_cond=cfg.feats_cond,
        use_high_res_feats=True,
        image_size=dataset.image_size,
    ).cuda()

    diffusion = GaussianDiffusion(
        model,
        image_size=dataset.image_size,
        timesteps=1000,  # number of steps
        sampling_timesteps=100,
        loss_type="l2",  # L1 or L2
        objective="pred_x0",
        beta_schedule="cosine",
    ).cuda()

    print(f"using lr {cfg.lr}")
    trainer = Trainer(
        diffusion,
        dataloader=dl,
        train_batch_size=train_batch_size,
        train_lr=cfg.lr,
        train_num_steps=700000,  # total training steps
        gradient_accumulate_every=1,  # gradient accumulation steps
        ema_decay=0.995,  # exponential moving average decay
        amp=False,  # turn on mixed precision
        sample_every=1000,
        wandb_every=50,
        save_every=5000,
        num_samples=1,
        warmup_period=1_000,
        checkpoint_path=cfg.checkpoint_path,
        wandb_config=cfg.wandb,
        run_name=cfg.name,
        dist_loss_weight=0,
        smooth_loss_weight=cfg.dataset.smooth_loss_weight,
        cfg=cfg,
    )
    sampling_type = cfg.sampling_type
    use_dataset_pose = True

    if sampling_type == "simple":
        with torch.no_grad():
            for _ in range(1):
                # step = 2
                # for i in range(150, 1000):
                for i in range(0, 1000):
                    # for i in [0, 2, 322]:  # range(1000):
                    # video_idx = i
                    # start_idx = 0  # i * step
                    # end_idx = start_idx + step  # (i + 1) * step
                    # ctxt_idx = [start_idx]  # [i * step]
                    # trgt_idx = np.array([end_idx], dtype=np.int64)
                    # if i[1] == "flip":
                    #     trgt_idx = np.array([start_idx], dtype=np.int64)
                    #     ctxt_idx = [end_idx]
                    # ctxt_idx_np = np.array(ctxt_idx, dtype=np.int64)
                    # trgt_idx_np = np.array(trgt_idx, dtype=np.int64)
                    # print(f"Starting rendering step {ctxt_idx_np}, {trgt_idx_np}")
                    # data = dataset.data_for_video(
                    #     video_idx=video_idx, ctxt_idx=ctxt_idx_np, trgt_idx=trgt_idx_np,
                    # )
                    data = dataset[i]  # next(iter(dl))
                    inp = to_gpu(data[0], "cuda")
                    for k in inp.keys():
                        inp[k] = inp[k].unsqueeze(0)
                    num_samples = 2
                    for j in range(num_samples):
                        print(f"Starting sample {j}")
                        out = trainer.ema.ema_model.sample(batch_size=1, inp=inp)
                        # out = trainer.model.sample(batch_size=1, inp=inp)
                        flow = out["flow"]
                        # compute max abs value
                        max_flow = torch.max(torch.abs(flow))
                        print(f"max flow {max_flow}")
                        # if max_flow < 1:
                        #     continue
                        median_flow = torch.median(torch.abs(flow))
                        print(f"median flow {median_flow}")
                        # if median_flow > 0.5:
                        #     continue
                        # count number of pixels with flow > 1
                        indices = torch.where(torch.abs(flow) > 1)
                        num_indices = indices[0].shape[0]
                        print(f"num indices {num_indices}")
                        # if num_indices < 600:
                        #     continue
                        out = trainer.model.sample(batch_size=1, inp=inp)
                        frames = prepare_video_viz(out)

                        denoised_f = os.path.join(run_dir, "video.mp4")
                        imageio.mimwrite(denoised_f, frames, fps=8, quality=7)
                        wandb.log(
                            {
                                "vid/interp": wandb.Video(
                                    denoised_f,
                                    format="mp4",
                                    fps=8,
                                    caption=f"max flow {max_flow}, ratio {median_flow}, video {i}",
                                ),
                            }
                        )
                        ctxt_img = (
                            trainer.model.unnormalize(inp["ctxt_rgb"][:, 0])
                            .cpu()
                            .detach()
                        )
                        ctxt_img = torch.clip(ctxt_img, 0, 1)
                        trgt_img = (
                            trainer.model.unnormalize(inp["trgt_rgb"][:, 0])
                            .cpu()
                            .detach()
                        )
                        trgt_img = torch.clip(trgt_img, 0, 1)
                        flows, arrowed_flows, flows_torch = prepare_flows(
                            out["flow"], ctxt_img, run_dir, i, j
                        )
                        image_dict = {
                            "result/trgt_rgb": wandb.Image(
                                make_grid(trgt_img).permute(1, 2, 0).numpy()
                            ),
                            "result/ctxt_rgb": wandb.Image(
                                make_grid(ctxt_img).permute(1, 2, 0).numpy()
                            ),
                            # "result/input_render": wandb.Image(
                            #     make_grid(out["rgb"].cpu().detach())
                            #     .permute(1, 2, 0)
                            #     .numpy()
                            # ),
                            "result/output": wandb.Image(
                                make_grid(
                                    trainer.model.normalize(out["images"])
                                    .cpu()
                                    .detach()
                                )
                                .permute(1, 2, 0)
                                .numpy()
                            ),
                            "result/flow": flows,
                            "result/arrowed_flow": arrowed_flows,
                        }

                        #
                        # # ax.set_xlabel("X")
                        # # ax.set_ylabel("Y")
                        # # ax.set_zlabel("Z")
                        #
                        # # Turn off tick labels
                        # ax.set_yticklabels([])
                        # ax.set_xticklabels([])
                        # ax.set_zticklabels([])
                        #
                        # plt.savefig(f"{run_dir}/trajectory.png")
                        # plt.close(fig)
                        # image_dict["result/trajectory"] = wandb.Image(
                        #     plt.imread(f"{run_dir}/trajectory.png")
                        # )
                        #
                        # # concat all frames along width into one image
                        # for f in range(len(frames)):
                        #     frames[f] = torch.from_numpy(frames[f])
                        #     depth_frames[f] = torch.from_numpy(depth_frames[f])
                        # print(len(frames))
                        # frames = frames[3:][::4]
                        # depth_frames = depth_frames[3:][::4]
                        #
                        # frames_cat = torch.cat(frames, dim=1)
                        # depth_frames_cat = torch.cat(depth_frames, dim=1)
                        # # print(
                        # #     f"frames_cat shape: {frames_cat.shape}, depth: {depth_frames_cat.shape}"
                        # # )
                        # # add to image dict
                        # image_dict["result/concat_video"] = wandb.Image(
                        #     make_grid(frames_cat).numpy()
                        # )
                        # image_dict["result/concat_video_depth"] = wandb.Image(
                        #     make_grid(depth_frames_cat).numpy()
                        # )
                        wandb.log(image_dict)
                        # save ctxt, trgt, output, flow, arrowed flow
                        print(
                            f"ctxt shape {ctxt_img.shape}, trgt shape {trgt_img.shape}, output shape {out['images'].shape}"
                        )
                        ctxt_img = ctxt_img[0].permute(1, 2, 0).numpy()
                        trgt_img = trgt_img[0].permute(1, 2, 0).numpy()
                        Image.fromarray((ctxt_img * 255).astype(np.uint8)).save(
                            f"{run_dir}/{i}/{j}_ctxt.png"
                        )
                        Image.fromarray((trgt_img * 255).astype(np.uint8)).save(
                            f"{run_dir}/{i}/{j}_trgt.png"
                        )
                        # print(f"flow shape {out['flow'].shape}")
                        flow = rearrange(
                            flows_torch.cpu().detach(), "b c h w -> b h w c"
                        ).numpy()[0]
                        Image.fromarray((flow * 255).astype(np.uint8)).save(
                            f"{run_dir}/{i}/{j}_flow_x.png"
                        )


from torchvision.utils import flow_to_image


def prepare_flows(flows, img, run_dir, idx_i, idx_j):
    flow = flow_to_image(flows)
    new_flows = flow.type(torch.float32) / 255.0
    new_flows_torch = new_flows
    print(f"new flows shape {new_flows.shape}")
    new_flows = wandb.Image(new_flows, caption="flow")

    img = rearrange(img, "b c h w -> b h w c")
    img = img[0].cpu().detach()
    flows = rearrange(flows, "b c h w -> b h w c")
    flows = flows[0].cpu().detach()
    # arrowed_flows = put_optical_flow_arrows_on_image(img, flows)
    # arrowed_flows = wandb.Image(arrowed_flows, caption="arrowed flow")
    # img = rearrange(img, "h w c -> c h w")
    out_dir = run_dir
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(os.path.join(out_dir, str(idx_i)), exist_ok=True)
    # img[:] = 1.0
    arrowed_flows = visualizeFlow(
        img.numpy(), flows.numpy(), f"{out_dir}/{idx_i}/{idx_j}_arrows.png"
    )
    arrowed_flows = rearrange(arrowed_flows, "h w c -> () c h w")
    arrowed_flows = torch.from_numpy(arrowed_flows).type(torch.float32)
    print(f"arrowed flows shape {arrowed_flows.shape}")
    arrowed_flows_img = wandb.Image(arrowed_flows, caption="arrowed flow")
    return new_flows, arrowed_flows_img, new_flows_torch


def prepare_video_viz(out):
    frames = out["videos"]
    for f in range(len(frames)):
        frames[f] = rearrange(frames[f], "b h w c -> h (b w) c")

    # depth_frames = out["depth_videos"]
    # for f in range(len(depth_frames)):
    #     depth_frames[f] = rearrange(depth_frames[f], "(n b) h w -> n h (b w)", n=1)

    # conditioning_depth = out["conditioning_depth"].cpu()
    # resize to depth_frames
    # conditioning_depth = F.interpolate(
    #     conditioning_depth[:, None],
    #     size=depth_frames[0].shape[-2:],
    #     mode="bilinear",
    #     antialias=True,
    # )[:, 0]
    # depth_frames.append(conditioning_depth)
    #
    # depth = torch.cat(depth_frames, dim=0)
    # print(f"depth shape: {depth.shape}")
    #
    # depth = (
    #     torch.from_numpy(
    #         jet_depth(depth[:].cpu().detach().view(depth.shape[0], depth.shape[-1], -1))
    #     )
    #     * 255
    # )
    # convert depth to list of images
    # depth_frames = []
    # for i in range(depth.shape[0]):
    #     depth_frames.append(depth[i].cpu().detach().numpy().astype(np.uint8))
    # conditioning_depth = out["conditioning_depth"]
    # conditioning_depth = (
    #     torch.from_numpy(
    #         jet_depth(
    #             conditioning_depth.cpu()
    #             .detach()
    #             .view(conditioning_depth.shape[0], conditioning_depth.shape[-1], -1)
    #         )
    #     )
    #     * 255
    # )
    return frames


if __name__ == "__main__":
    train()
