import sys
import os
import wandb
import hydra
from omegaconf import DictConfig
from torch.utils.data import Dataset, DataLoader

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from denoising_diffusion_pytorch.denoising_swiss import (
    GaussianDiffusion,
    Trainer,
)
import data_io

from Swiss.swiss import SwissModel
import torch
import numpy as np


def worker_init_fn(worker_id):
    np.seed(np.random.get_state()[1][0] + worker_id)
    torch.manual_seed(np.random.get_state()[1][0] + worker_id)


@hydra.main(
    version_base=None, config_path="../configurations/", config_name="config",
)
def train(cfg: DictConfig):
    train_settings = get_train_settings(cfg.setting_name, cfg.ngpus)
    cfg.num_context = train_settings["num_context"]
    cfg.num_target = train_settings["num_target"]
    dataset = data_io.get_dataset(cfg)
    # set torch seed
    # torch.manual_seed(10)

    dl = DataLoader(
        dataset,
        batch_size=train_settings["batch_size"],
        shuffle=True,
        pin_memory=True,
        num_workers=0,
        worker_init_fn=lambda id: np.random.seed(id * 4),
    )
    model_type = cfg.model_type
    model = SwissModel().cuda()

    diffusion = GaussianDiffusion(
        model,
        image_size=dataset.image_size,
        timesteps=1000,  # number of steps
        sampling_timesteps=1000,
        loss_type="l2",  # L1 or L2
        objective="pred_x0",
        beta_schedule="cosine",
    ).cuda()

    print(f"using settings {train_settings}")

    print(f"using lr {cfg.lr}")
    trainer = Trainer(
        diffusion,
        dataloader=dl,
        train_batch_size=train_settings["batch_size"],
        train_lr=cfg.lr,
        train_num_steps=1000000,  # total training steps
        gradient_accumulate_every=1,  # gradient accumulation steps
        ema_decay=0.995,  # exponential moving average decay
        amp=False,  # turn on mixed precision
        sample_every=5000,
        wandb_every=5000,
        save_every=2000,
        num_samples=1000,
        warmup_period=1_000,
        checkpoint_path=cfg.checkpoint_path,
        wandb_config=cfg.wandb,
        run_name=cfg.name,
        dist_loss_weight=cfg.dataset.dist_loss_weight,
    )
    trainer.train()


def get_train_settings(name, ngpus):
    if name == "coarse_smaller_batch_2trgt":
        return {
            "n_coarse": 64,
            "n_fine": 0,
            "n_coarse_coarse": 32,
            "n_coarse_fine": 0,
            "num_pixels": 16 ** 2,
            "batch_size": 5 * ngpus,
            "num_context": 1,
            "num_target": 2,
            "n_feats_out": 64,
        }
    if name == "coarse_smaller_batch_2trgt_3ctxt":
        return {
            "n_coarse": 64,
            "n_fine": 0,
            "n_coarse_coarse": 32,
            "n_coarse_fine": 0,
            "num_pixels": 16 ** 2,
            "batch_size": 3 * ngpus,
            "num_context": 3,
            "num_target": 2,
            "n_feats_out": 64,
        }
    if name == "coarse_smaller_batch_2trgt_3ctxt_sh":
        return {
            "n_coarse": 64,
            "n_fine": 0,
            "n_coarse_coarse": 32,
            "n_coarse_fine": 0,
            "num_pixels": 16 ** 2,
            "batch_size": 1 * ngpus,
            "num_context": 3,
            "num_target": 2,
            "n_feats_out": 64,
        }
    if name == "coarse_smaller_batch_2trgt_uvit":
        return {
            "n_coarse": 64,
            "n_fine": 0,
            "n_coarse_coarse": 64,
            "n_coarse_fine": 0,
            "num_pixels": 16 ** 2,
            "batch_size": 5 * ngpus,
            "num_context": 1,
            "num_target": 2,
            "n_feats_out": 64,
        }
    if name == "coarser_smaller_batch_2trgt":
        return {
            "n_coarse": 64,
            "n_fine": 0,
            "n_coarse_coarse": 24,
            "n_coarse_fine": 0,
            "num_pixels": 16 ** 2,
            "batch_size": 3 * ngpus,
            "num_context": 1,
            "num_target": 2,
            "n_feats_out": 3,
        }
    elif name == "fine_smaller_batch_2trgt":
        return {
            "n_coarse": 64,
            "n_fine": 32,
            "n_coarse_coarse": 64,
            "n_coarse_fine": 0,
            "num_pixels": 16 ** 2,
            "batch_size": 2 * ngpus,
            "num_context": 1,
            "num_target": 2,
        }
    elif name == "fine_smaller_batch_2trgt_3ctxt_sh":
        return {
            "n_coarse": 64,
            "n_fine": 32,
            "n_coarse_coarse": 32,
            "n_coarse_fine": 0,
            "num_pixels": int(16 ** 2),
            "batch_size": 1 * ngpus,
            "num_context": 3,
            "num_target": 2,
            "n_feats_out": 64,
        }
    elif name == "nmr_1ctxt_a100":
        return {
            "n_coarse": 64,
            "n_fine": 32,
            "n_coarse_coarse": 32,
            "n_coarse_fine": 0,
            "num_pixels": int(16 ** 2),
            "batch_size": 5 * ngpus,
            "num_context": 1,
            "num_target": 2,
            "n_feats_out": 64,
            "use_viewdir": True,
        }
    elif name == "re_1ctxt_a100":
        return {
            "n_coarse": 64,
            "n_fine": 32,
            "n_coarse_coarse": 32,
            "n_coarse_fine": 0,
            "num_pixels": int(16 ** 2),
            "batch_size": 1000 * ngpus,
            "num_context": 1,
            "num_target": 1,
            "n_feats_out": 64,
            "use_viewdir": False,
        }
    elif name == "rooms_3ctxt_a100":
        return {
            "n_coarse": 64,
            "n_fine": 32,
            "n_coarse_coarse": 32,
            "n_coarse_fine": 0,
            "num_pixels": int(18 ** 2),
            "batch_size": 2 * ngpus,
            "num_context": 3,
            "num_context": 3,
            "num_target": 2,
            "n_feats_out": 64,
            "use_viewdir": False,
        }
    elif name == "nmr360_3ctxt_a100":
        return {
            "n_coarse": 64,
            "n_fine": 32,
            "n_coarse_coarse": 32,
            "n_coarse_fine": 0,
            "num_pixels": int(18 ** 2),
            "batch_size": 2 * ngpus,
            "num_context": 3,
            "num_target": 2,
            "n_feats_out": 64,
            "use_viewdir": True,
        }
    elif name == "nmr360_1ctxt_sh":
        return {
            "n_coarse": 64,
            "n_fine": 32,
            "n_coarse_coarse": 32,
            "n_coarse_fine": 0,
            "num_pixels": int(14 ** 2),
            "batch_size": 2 * ngpus,
            "num_context": 1,
            "num_target": 2,
            "n_feats_out": 64,
            "use_viewdir": True,
        }
    elif name == "coarse_larger_batch_2trgt":
        return {
            "n_coarse": 64,
            "n_fine": 0,
            "n_coarse_coarse": 64,
            "n_coarse_fine": 0,
            "num_pixels": 8 ** 2 * 2,
            "batch_size": 4 * ngpus,
            "num_context": 1,
            "num_target": 2,
        }
    elif name == "fine_larger_batch_2trgt":
        return {
            "n_coarse": 64,
            "n_fine": 32,
            "n_coarse_coarse": 64,
            "n_coarse_fine": 32,
            "num_pixels": 8 ** 2 * 2,
            "batch_size": 6 * ngpus,
            "num_context": 1,
            "num_target": 2,
        }
    elif name == "debug":
        return {
            "n_coarse": 64,
            "n_fine": 0,
            "n_coarse_coarse": 32,
            "n_coarse_fine": 0,
            "num_pixels": 8 ** 2 * 2,
            "batch_size": 1 * ngpus,
            "num_context": 1,
            "num_target": 2,
            "n_feats_out": 64,
        }
    else:
        raise ValueError(f"unknown setting {name}")


if __name__ == "__main__":
    print(f"running {__file__}")
    train()
