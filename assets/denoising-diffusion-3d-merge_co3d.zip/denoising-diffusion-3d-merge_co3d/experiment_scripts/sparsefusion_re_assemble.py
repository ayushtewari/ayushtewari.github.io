import os
from PIL import Image

root = (
    "/nobackup/nvme1/gcaz/output/demo/sf/realestate10k/realestate_5_15_3D/render_imgs/"
)
out_folder = "/home/ayusht/sparsefusion/"
folders = os.listdir(root)

for scene_idx, folder in enumerate(folders):
    scene_folder = os.path.join(root, folder)
    print(scene_folder)
    scene_folder = os.path.join(scene_folder, "rgb_img")
    imgs = [f for f in os.listdir(scene_folder) if f.endswith(".png")]
    for img_idx, img in enumerate(imgs):
        img_path = os.path.join(scene_folder, img)
        # I = cv2.imread(img_path)
        I = Image.open(img_path)
        #
        # resize to 64
        I = I.resize((64, 64), Image.ANTIALIAS)
        # I = cv2.resize(I, (64, 64))
        out_path = os.path.join(
            "/home/ayusht/sparsefusion/", f"{scene_idx:04}_{img_idx:04}.png"
        )
        # cv2.imwrite(out_path, I)
        I.save(out_path)
