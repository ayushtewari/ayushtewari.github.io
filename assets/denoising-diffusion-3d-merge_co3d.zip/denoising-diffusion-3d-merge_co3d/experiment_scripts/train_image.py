import sys
import os
import wandb
import hydra
from omegaconf import DictConfig
from torch.utils.data import Dataset, DataLoader

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from denoising_diffusion_pytorch import Unet, GaussianDiffusion, Trainer
import data_io


@hydra.main(
    version_base=None, config_path="../configurations/", config_name="config",
)
def train(cfg: DictConfig):
    run = wandb.init(**cfg.wandb)
    wandb.run.log_code(".")

    run_dir = run.dir
    wandb.save(os.path.join(run_dir, "checkpoint*"))
    wandb.save(os.path.join(run_dir, "video*"))

    model = Unet(dim=64, dim_mults=(1, 1, 2, 4)).cuda()
    # model = Unet(dim=64, dim_mults=(2, 4, 8)).cuda()
    train_batch_size = cfg.batch_size

    # dataset
    dataset = data_io.get_dataset(cfg.dataset)
    dl = DataLoader(
        dataset,
        batch_size=train_batch_size,
        shuffle=True,
        pin_memory=True,
        num_workers=32,
    )

    diffusion = GaussianDiffusion(
        model,
        image_size=48,
        timesteps=1000,  # number of steps
        sampling_timesteps=250,  # number of sampling timesteps (using ddim for faster inference [see citation for ddim paper])
        loss_type="l1",  # L1 or L2
        objective="pred_x0",
        beta_schedule="cosine",
    ).cuda()

    trainer = Trainer(
        diffusion,
        dataloader=dl,
        train_batch_size=train_batch_size,
        train_lr=2e-5,
        train_num_steps=700000,  # total training steps
        gradient_accumulate_every=1,  # gradient accumulation steps
        ema_decay=0.995,  # exponential moving average decay
        amp=False,  # turn on mixed precision
        results_folder=run_dir,
        sample_every=1000,
        save_every=5000,
        num_samples=4,
        checkpoint_path=cfg.checkpoint_path,
    )

    trainer.train()


if __name__ == "__main__":
    train()
