import os
import cv2

root = "/scratch2/weka/tenenbaum/ayusht/projects/denoising-diffusion-3d/wandb/run-20230516_142134-bvi2h022/files/generated_frames/"
out_folder = (
    "/scratch2/weka/tenenbaum/ayusht/projects/denoising-diffusion-3d/re_fid/pn/"
)

imgs = [f for f in os.listdir(root) if f.endswith(".png")]
for img_idx, img in enumerate(imgs):
    # parse img with _
    # scene_idx = int(img.split("_")[1])
    # if scene_idx > 60:
    #     print(scene_idx)
    # img_path = os.path.join(root, img)
    # I = cv2.imread(img_path)

    # resize to 64
    # I = cv2.resize(I, (64, 64))
    # out_path = os.path.join(
    #     "/home/ayusht/sparsefusion/", f"{scene_idx:04}_{img_idx:04}.png"
    # )
    # cv2.imwrite(out_path, I)
    # move file to out_folder


