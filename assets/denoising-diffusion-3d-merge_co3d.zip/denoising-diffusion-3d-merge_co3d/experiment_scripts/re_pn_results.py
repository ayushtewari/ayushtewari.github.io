import sys
import os
import wandb
import hydra
from omegaconf import DictConfig
from torch.utils.data import Dataset, DataLoader

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from denoising_diffusion_pytorch.pixelnerf_trainer import Trainer, PixelNeRFModelWrapper
import data_io
from einops import rearrange

# from PixelNeRF import PixelNeRFModel, PixelNeRFImageModel
from PixelNeRF import PixelNeRFModelVanilla
import torch
import imageio
import numpy as np
from utils import *
from torchvision.utils import make_grid
from accelerate import DistributedDataParallelKwargs
from accelerate import Accelerator
from results_configs import re_indices
import matplotlib.pyplot as plt
import torch.nn.functional as F
from PIL import Image


@hydra.main(
    version_base=None, config_path="../configurations/", config_name="config",
)
def train(cfg: DictConfig):
    run = wandb.init(**cfg.wandb)
    wandb.run.log_code(".")
    wandb.run.name = cfg.name
    print(f"run dir: {run.dir}")
    run_dir = run.dir
    wandb.save(os.path.join(run_dir, "checkpoint*"))
    wandb.save(os.path.join(run_dir, "video*"))
    # initialize the accelerator at the beginning
    ddp_kwargs = DistributedDataParallelKwargs(find_unused_parameters=True)
    accelerator = Accelerator(
        split_batches=True, mixed_precision="no", kwargs_handlers=[ddp_kwargs],
    )

    # dataset
    train_batch_size = cfg.batch_size
    dataset = data_io.get_dataset(cfg)
    dl = DataLoader(
        dataset,
        batch_size=train_batch_size,
        shuffle=False,
        pin_memory=True,
        num_workers=0,
    )
    torch.manual_seed(17)

    # model = PixelNeRFModel(near=1.2, far=4.0, dim=64, dim_mults=(1, 1, 2, 4)).cuda()
    render_settings = {
        "n_coarse": 64,
        "n_fine": 64,
        "n_coarse_coarse": 32,
        "n_coarse_fine": 0,
        "num_pixels": 64 ** 2,
        "n_feats_out": 64,
        "num_context": 1,
        "sampling": "patch",
        "cnn_refine": False,
        "self_condition": False,
        "lindisp": False,
        # "cnn_refine": True,
    }
    model_type = "resnet"
    backbone = None
    vit_path = None
    model = PixelNeRFModelVanilla(
        near=dataset.z_near,
        far=dataset.z_far,
        model=model_type,
        backbone=backbone,
        background_color=dataset.background_color,
        viz_type=cfg.dataset.viz_type,
        use_first_pool=cfg.use_first_pool,
        lindisp=cfg.dataset.lindisp,
        path=vit_path,
    ).cuda()

    modelwrapper = PixelNeRFModelWrapper(
        model, image_size=dataset.image_size, loss_type="l2",  # L1 or L2
    ).cuda()

    print(f"using lr {cfg.lr}")
    trainer = Trainer(
        reconstruction_model=modelwrapper,
        dataloader=dl,
        train_batch_size=train_batch_size,
        train_lr=cfg.lr,
        train_num_steps=700000,  # total training steps
        gradient_accumulate_every=1,  # gradient accumulation steps
        ema_decay=0.995,  # exponential moving average decay
        amp=False,  # turn on mixed precision
        sample_every=5000,
        wandb_every=cfg.wandb_every,
        save_every=5000,
        num_samples=2,
        warmup_period=1_000,
        checkpoint_path=cfg.checkpoint_path,
        wandb_config=cfg.wandb,
        run_name=cfg.name,
    )
    sampling_type = cfg.sampling_type
    use_dataset_pose = True

    if sampling_type == "simple":
        with torch.no_grad():
            for _ in range(1):
                step = 150
                for i in range(61, 100):
                    video_idx = i
                    print(f"Starting video {video_idx}")

                    ctxt_idx = [150]  # [i * step]
                    trgt_idx = np.array([0], dtype=np.int64)

                    ctxt_idx_np = np.array(ctxt_idx, dtype=np.int64)
                    trgt_idx_np = np.array(trgt_idx, dtype=np.int64)

                    print(f"Starting rendering step {ctxt_idx_np}, {trgt_idx_np}")
                    data = dataset.data_for_video(
                        video_idx=video_idx, ctxt_idx=ctxt_idx_np, trgt_idx=trgt_idx_np,
                    )
                    inp = to_gpu(data[0], "cuda")
                    for k in inp.keys():
                        inp[k] = inp[k].unsqueeze(0)

                    if not use_dataset_pose:
                        poses = trainer.model.model.compute_poses(
                            "interpolation", inp, 5, max_angle=30
                        )
                        print(f"poses shape: {poses.shape}")
                        inp["render_poses"] = poses
                        inp["trgt_c2w"] = poses[-1].unsqueeze(0).unsqueeze(0).cuda()

                    print(f"len of idx: {len(ctxt_idx)}")
                    for j in range(1):
                        print(f"Starting sample {j}")
                        t = torch.zeros((1, 1), device="cuda").long()
                        frames = trainer.ema.ema_model.model.render_video(
                            inp, n=20, t=t
                        )
                        denoised_f = video_summary(
                            run_dir, frames, "denoised_view", fps=8
                        )
                        # target_f = os.path.join(run_dir, "target_view_circle.mp4")
                        # imageio.mimwrite(
                        #     target_f, target_frames, fps=5, quality=10,
                        # )

                        # concat all frames along width into one image
                        # frames_cat = concat_list_to_image(frames, 50)
                        # depth_frames_cat = concat_list_to_image(depth_frames, 50)
                        # target_frames_cat = concat_list_to_image(target_frames, 50)

                        # concat_video = wandb.Image(make_grid(frames_cat).numpy())
                        # concat_video_depth = wandb.Image(
                        #     make_grid(depth_frames_cat).numpy()
                        # )
                        # concat_video_target = wandb.Image(
                        #     make_grid(target_frames_cat).numpy()
                        # )

                        data_dict = {
                            "vid/interp": wandb.Video(
                                denoised_f, format="mp4", fps=4, caption=f"{video_idx}",
                            ),
                        }

                        wandb.log(data_dict)
                        ctxt_img = (
                            trainer.model.unnormalize(inp["ctxt_rgb"][:, 0])
                            .cpu()
                            .detach()
                        )
                        ctxt_img = torch.clip(ctxt_img, 0, 1)
                        trgt_img = (
                            trainer.model.unnormalize(inp["trgt_rgb"][:, 0])
                            .cpu()
                            .detach()
                        )
                        trgt_img = torch.clip(trgt_img, 0, 1)
                        image_dict = {
                            "result/trgt_rgb": wandb.Image(
                                make_grid(trgt_img).permute(1, 2, 0).numpy()
                            ),
                            "result/ctxt_rgb": wandb.Image(
                                make_grid(ctxt_img).permute(1, 2, 0).numpy()
                            ),
                        }
                        wandb.log(image_dict)
                        os.makedirs(
                            os.path.join(run_dir, "generated_frames"), exist_ok=True
                        )
                        for frame_idx, frame in enumerate(frames):
                            Image.fromarray(frame).save(
                                f"{run_dir}/generated_frames/video_{video_idx:04d}_frame_{frame_idx:04d}.png"
                            )


def video_summary(run_dir, frames, name, fps=8):
    denoised_f = os.path.join(run_dir, f"rgb_{name}.mp4")
    imageio.mimwrite(denoised_f, frames, fps=fps, quality=10)
    denoised_f_depth = os.path.join(run_dir, f"depth_{name}.mp4")
    return denoised_f


def prepare_video_viz(out):
    frames = out["videos"]
    for f in range(len(frames)):
        frames[f] = rearrange(frames[f], "b h w c -> h (b w) c")

    depth_frames = out["depth_videos"]
    for f in range(len(depth_frames)):
        depth_frames[f] = rearrange(depth_frames[f], "(n b) h w -> n h (b w)", n=1)

    conditioning_depth = out["conditioning_depth"].cpu()
    # resize to depth_frames
    conditioning_depth = F.interpolate(
        conditioning_depth[:, None],
        size=depth_frames[0].shape[-2:],
        mode="bilinear",
        antialias=True,
    )[:, 0]
    depth_frames.append(conditioning_depth)

    depth = torch.cat(depth_frames, dim=0)
    print(f"depth shape: {depth.shape}")

    depth = (
        torch.from_numpy(
            jet_depth(depth[:].cpu().detach().view(depth.shape[0], depth.shape[-1], -1))
        )
        * 255
    )
    # convert depth to list of images
    depth_frames = []
    for i in range(depth.shape[0]):
        depth_frames.append(depth[i].cpu().detach().numpy().astype(np.uint8))
    # conditioning_depth = out["conditioning_depth"]
    # conditioning_depth = (
    #     torch.from_numpy(
    #         jet_depth(
    #             conditioning_depth.cpu()
    #             .detach()
    #             .view(conditioning_depth.shape[0], conditioning_depth.shape[-1], -1)
    #         )
    #     )
    #     * 255
    # )
    return (
        frames,
        depth_frames[:-1],
        rearrange(torch.from_numpy(depth_frames[-1]), "h w c -> () c h w"),
    )


if __name__ == "__main__":
    train()
