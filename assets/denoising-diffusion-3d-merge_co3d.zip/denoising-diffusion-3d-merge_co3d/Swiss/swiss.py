import torch, torchvision
from torch import nn, einsum
import torch.nn.functional as F
import sys
import os
import numpy as np
import functools
from einops import rearrange, repeat
from PixelNeRF.pixelnerf_helpers import PositionalEncoding

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class SwissModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.pos_enc = PositionalEncoding(freq_factor=1.5, d_in=7)
        in_dim = self.pos_enc.d_out
        self.block1 = nn.Sequential(
            nn.Linear(in_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU(),
        )
        self.block2 = nn.Sequential(
            nn.Linear(256 + in_dim, 256), nn.ReLU(), nn.Linear(256, 2),
        )
        self.out = nn.Linear(2, 2)

        self.channels = 1
        self.self_condition = False
        self.predict_latent = True

    def get_feats(self, inp):
        inp = self.pos_enc(inp)
        hidden = self.block1(inp)
        latent = self.block2(torch.cat([hidden, inp], dim=1))
        latent = self.out(latent)
        return latent

    # @torch.no_grad()

    def forward(self, model_input, t, x_self_cond=None):
        ctxt_img = model_input["ctxt_rgb"][:, 0, ...]
        trgt_img = model_input["noisy_trgt_rgb"]
        t = t.unsqueeze(1)
        # make t float
        t = t.float()
        matrix = model_input["matrix"]

        # print(
        #     f"ctxt_img shape {ctxt_img.shape}, trgt_img shape {trgt_img.shape}, t shape {t.shape}, matrix shape {matrix.shape}"
        # )
        trgt_inp = torch.cat([ctxt_img, trgt_img, t, matrix.view(-1, 4)], dim=1)
        out = self.get_feats(trgt_inp)

        if self.predict_latent:
            # latent = torch.cat([ctxt_img, out], dim=1)
            latent = out
            # print(f"latent shape {latent.shape}, matrix shape {matrix.shape}")
            observation = matrix @ latent.unsqueeze(-1)
        else:
            observation = torch.cat([ctxt_img, out], dim=1).unsqueeze(-1)
            latent = torch.linalg.inv(matrix) @ observation
            latent = latent.squeeze(-1)

        # print(f"matrix shape {matrix.shape}, latent shape {latent.shape}")
        # print(f"observation shape {observation.shape}")
        out_ctxt = observation[:, :1, 0]
        out_trgt = observation[:, 1:, 0]

        # print(f"diff {out_ctxt - ctxt_img}")
        return out_ctxt, out_trgt, latent
