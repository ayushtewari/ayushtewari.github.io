import math
from pathlib import Path
from random import random
from collections import OrderedDict
import numpy as np
from functools import partial
from collections import namedtuple

import torch
from torch import nn
import torch.nn.functional as F

from torch.optim import Adam
from torchvision import utils

from einops import rearrange, reduce, repeat

from tqdm.auto import tqdm
from ema_pytorch import EMA

from accelerate import Accelerator
from torchvision.utils import make_grid

from denoising_diffusion_pytorch.version import __version__
import wandb
import sys
import os
import imageio
from accelerate import DistributedDataParallelKwargs

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# from utils import *
from layers import *
from losses import *
import flow_vis

# constants
ModelPrediction = namedtuple("ModelPrediction", ["pred_noise", "pred_x_start", "flow"])


def right_pad_dims_to(x, t):
    padding_dims = x.ndim - t.ndim
    if padding_dims <= 0:
        return t
    return t.view(*t.shape, *((1,) * padding_dims))


def extract(a, t, x_shape):
    b, *_ = t.shape
    out = a.gather(-1, t)
    return out.reshape(b, *((1,) * (len(x_shape) - 1)))


def linear_beta_schedule(timesteps):
    """
    linear schedule, proposed in original ddpm paper
    """
    scale = 1000 / timesteps
    beta_start = scale * 0.0001
    beta_end = scale * 0.02
    return torch.linspace(beta_start, beta_end, timesteps, dtype=torch.float64)


def cosine_beta_schedule(timesteps, s=0.008):
    """
    cosine schedule
    as proposed in https://openreview.net/forum?id=-NEXDKk8gZ
    """
    steps = timesteps + 1
    t = torch.linspace(0, timesteps, steps, dtype=torch.float64) / timesteps
    alphas_cumprod = torch.cos((t + s) / (1 + s) * math.pi * 0.5) ** 2
    alphas_cumprod = alphas_cumprod / alphas_cumprod[0]
    betas = 1 - (alphas_cumprod[1:] / alphas_cumprod[:-1])
    return torch.clip(betas, 0, 0.999)


def sigmoid_beta_schedule(timesteps, start=-3, end=3, tau=1, clamp_min=1e-5):
    """
    sigmoid schedule
    proposed in https://arxiv.org/abs/2212.11972 - Figure 8
    better for images > 64x64, when used during training
    """
    steps = timesteps + 1
    t = torch.linspace(0, timesteps, steps, dtype=torch.float64) / timesteps
    v_start = torch.tensor(start / tau).sigmoid()
    v_end = torch.tensor(end / tau).sigmoid()
    alphas_cumprod = (-((t * (end - start) + start) / tau).sigmoid() + v_end) / (
        v_end - v_start
    )
    alphas_cumprod = alphas_cumprod / alphas_cumprod[0]
    betas = 1 - (alphas_cumprod[1:] / alphas_cumprod[:-1])
    return torch.clip(betas, 0, 0.999)


class GaussianDiffusion(nn.Module):
    def __init__(
        self,
        model,
        image_size,
        timesteps=1000,
        sampling_timesteps=None,
        loss_type="l1",
        objective="pred_noise",
        beta_schedule="sigmoid",
        schedule_fn_kwargs=dict(),
        p2_loss_weight_gamma=0.0,  # p2 loss weight, from https://arxiv.org/abs/2204.00227 - 0 is equivalent to weight of 1 across time - 1. is recommended
        p2_loss_weight_k=1,
        ddim_sampling_eta=0.0,
        auto_normalize=True,
        deterministic=False,
        use_guidance=False,
        guidance_scale=1.0,
    ):
        super().__init__()
        assert not (type(self) == GaussianDiffusion and model.channels != model.out_dim)
        # assert not model.enc.model.random_or_learned_sinusoidal_cond

        self.model = model
        self.channels = self.model.channels
        self.self_condition = self.model.self_condition

        self.image_size = image_size
        self.guidance_scale = guidance_scale
        self.use_guidance = use_guidance

        self.objective = objective

        assert objective in {
            "pred_noise",
            "pred_x0",
            "pred_v",
        }, "objective must be either pred_noise (predict noise) or pred_x0 (predict image start) or pred_v (predict v [v-parameterization as defined in appendix D of progressive distillation paper, used in imagen-video successfully])"

        if beta_schedule == "linear":
            beta_schedule_fn = linear_beta_schedule
        elif beta_schedule == "cosine":
            beta_schedule_fn = cosine_beta_schedule
        elif beta_schedule == "sigmoid":
            beta_schedule_fn = sigmoid_beta_schedule
        else:
            raise ValueError(f"unknown beta schedule {beta_schedule}")

        betas = beta_schedule_fn(timesteps, **schedule_fn_kwargs)

        alphas = 1.0 - betas
        alphas_cumprod = torch.cumprod(alphas, dim=0)
        alphas_cumprod_prev = F.pad(alphas_cumprod[:-1], (1, 0), value=1.0)

        (timesteps,) = betas.shape
        self.num_timesteps = int(timesteps)
        self.loss_type = loss_type

        self.deterministic = deterministic
        # sampling related parameters

        self.sampling_timesteps = default(
            sampling_timesteps, timesteps
        )  # default num sampling timesteps to number of timesteps at training

        assert self.sampling_timesteps <= timesteps
        self.is_ddim_sampling = self.sampling_timesteps < timesteps
        self.ddim_sampling_eta = ddim_sampling_eta

        # helper function to register buffer from float64 to float32

        def register_buffer(name, val):
            return self.register_buffer(name, val.to(torch.float32))

        register_buffer("betas", betas)
        register_buffer("alphas_cumprod", alphas_cumprod)
        register_buffer("alphas_cumprod_prev", alphas_cumprod_prev)

        # calculations for diffusion q(x_t | x_{t-1}) and others

        register_buffer("sqrt_alphas_cumprod", torch.sqrt(alphas_cumprod))
        register_buffer(
            "sqrt_one_minus_alphas_cumprod", torch.sqrt(1.0 - alphas_cumprod)
        )
        register_buffer("log_one_minus_alphas_cumprod", torch.log(1.0 - alphas_cumprod))
        register_buffer("sqrt_recip_alphas_cumprod", torch.sqrt(1.0 / alphas_cumprod))
        register_buffer(
            "sqrt_recipm1_alphas_cumprod", torch.sqrt(1.0 / alphas_cumprod - 1)
        )

        # calculations for posterior q(x_{t-1} | x_t, x_0)

        posterior_variance = (
            betas * (1.0 - alphas_cumprod_prev) / (1.0 - alphas_cumprod)
        )

        # above: equal to 1. / (1. / (1. - alpha_cumprod_tm1) + alpha_t / beta_t)

        register_buffer("posterior_variance", posterior_variance)

        # below: log calculation clipped because the posterior variance is 0 at the beginning of the diffusion chain

        register_buffer(
            "posterior_log_variance_clipped",
            torch.log(posterior_variance.clamp(min=1e-20)),
        )
        register_buffer(
            "posterior_mean_coef1",
            betas * torch.sqrt(alphas_cumprod_prev) / (1.0 - alphas_cumprod),
        )
        register_buffer(
            "posterior_mean_coef2",
            (1.0 - alphas_cumprod_prev) * torch.sqrt(alphas) / (1.0 - alphas_cumprod),
        )

        # calculate p2 reweighting
        use_constant_p2_weight = True
        if use_constant_p2_weight:
            register_buffer(
                "p2_loss_weight",
                (p2_loss_weight_k + alphas_cumprod / (1 - alphas_cumprod))
                ** -p2_loss_weight_gamma,
            )
        else:
            snr = alphas_cumprod / (1 - alphas_cumprod)
            register_buffer(
                "p2_loss_weight", torch.minimum(snr, torch.ones_like(snr) * 5.0)
            )  # https://arxiv.org/pdf/2303.09556.pdf

        # auto-normalization of data [0, 1] -> [-1, 1] - can turn off by setting it to be False
        self.normalize = normalize_to_neg_one_to_one if auto_normalize else identity
        self.unnormalize = unnormalize_to_zero_to_one if auto_normalize else identity

    def predict_start_from_noise(self, x_t, t, noise):
        return (
            extract(self.sqrt_recip_alphas_cumprod, t, x_t.shape) * x_t
            - extract(self.sqrt_recipm1_alphas_cumprod, t, x_t.shape) * noise
        )

    def predict_noise_from_start(self, x_t, t, x0):
        return (
            extract(self.sqrt_recip_alphas_cumprod, t, x_t.shape) * x_t - x0
        ) / extract(self.sqrt_recipm1_alphas_cumprod, t, x_t.shape)

    def predict_v(self, x_start, t, noise):
        return (
            extract(self.sqrt_alphas_cumprod, t, x_start.shape) * noise
            - extract(self.sqrt_one_minus_alphas_cumprod, t, x_start.shape) * x_start
        )

    def predict_start_from_v(self, x_t, t, v):
        return (
            extract(self.sqrt_alphas_cumprod, t, x_t.shape) * x_t
            - extract(self.sqrt_one_minus_alphas_cumprod, t, x_t.shape) * v
        )

    def q_posterior(self, x_start, x_t, t):
        posterior_mean = (
            extract(self.posterior_mean_coef1, t, x_t.shape) * x_start
            + extract(self.posterior_mean_coef2, t, x_t.shape) * x_t
        )
        posterior_variance = extract(self.posterior_variance, t, x_t.shape)
        posterior_log_variance_clipped = extract(
            self.posterior_log_variance_clipped, t, x_t.shape
        )
        return posterior_mean, posterior_variance, posterior_log_variance_clipped

    def model_predictions(
        self, inp, t, guidance_scale=1.0, x_self_cond=None, clip_x_start=False
    ):
        x = inp["noisy_trgt_rgb"]
        model_output, flow, uncond_model_output, uncond_flow = self.model(
            inp, t, guidance_scale=guidance_scale, x_self_cond=x_self_cond
        )
        # print(f"model_outpus range: {model_output.min()} {model_output.max()}")
        # maybe_clip = (
        #     partial(torch.clamp, min=-1.0, max=1.0) if clip_x_start else identity
        # )
        dynamic_threshold = True
        dynamic_thresholding_percentile = 0.95
        if dynamic_threshold:
            # following pseudocode in appendix
            # s is the dynamic threshold, determined by percentile of absolute values of reconstructed sample per batch element
            # print("using dynamic thresholding")

            def maybe_clip(x_start):
                s = torch.quantile(
                    rearrange(x_start, "b ... -> b (...)").abs(),
                    dynamic_thresholding_percentile,
                    dim=-1,
                )

                s.clamp_(min=1.0)
                s = right_pad_dims_to(x_start, s)
                x_start = x_start.clamp(-s, s) / s
                return x_start

        else:
            maybe_clip = (
                partial(torch.clamp, min=-1.0, max=1.0) if clip_x_start else identity
            )

        if self.objective == "pred_noise":
            pred_noise = model_output
            x_start = self.predict_start_from_noise(x, t, pred_noise)
            x_start = maybe_clip(x_start)
        elif self.objective == "pred_x0":
            x_start = model_output

            if self.use_guidance and guidance_scale > 1.0:
                uncond_x_start = uncond_model_output
                x_start = uncond_x_start + guidance_scale * (x_start - uncond_x_start)

            x_start = maybe_clip(x_start)

            num_targets = x_start.shape[0] // x.shape[0]
            x_start = rearrange(x_start, "(b nt) c h w -> b nt c h w", nt=num_targets)[
                :, 0, ...
            ]
            pred_noise = self.predict_noise_from_start(x, t, x_start)
        elif self.objective == "pred_v":
            v = model_output
            x_start = self.predict_start_from_v(x, t, v)
            x_start = maybe_clip(x_start)
            pred_noise = self.predict_noise_from_start(x, t, x_start)
        return ModelPrediction(pred_noise, x_start, flow)

    def p_mean_variance(self, inp, t, x_self_cond=None, clip_denoised=True):
        x = inp["noisy_trgt_rgb"]
        preds = self.model_predictions(inp, t, x_self_cond)
        x_start = preds.pred_x_start
        if clip_denoised:
            x_start.clamp_(-1.0, 1.0)
        model_mean, posterior_variance, posterior_log_variance = self.q_posterior(
            x_start=x_start, x_t=x, t=t
        )
        return model_mean, posterior_variance, posterior_log_variance, x_start

    @torch.no_grad()
    def p_sample(self, inp, t: int, x_self_cond=None):
        x = inp["noisy_trgt_rgb"]
        b, *_, device = *x.shape, x.device
        batched_times = torch.full((x.shape[0],), t, device=x.device, dtype=torch.long)
        model_mean, _, model_log_variance, x_start = self.p_mean_variance(
            inp=inp, t=batched_times, x_self_cond=x_self_cond, clip_denoised=True
        )
        noise = torch.randn_like(x) if t > 0 else 0.0  # no noise if t == 0
        pred_img = model_mean + (0.5 * model_log_variance).exp() * noise
        return pred_img, x_start

    @torch.no_grad()
    def p_sample_loop(self, shape, return_all_timesteps=False, inp=None):
        batch, device = shape[0], self.betas.device

        img = torch.randn(shape, device=device)
        imgs = [img]

        print("p sample loop")

        x_start = None
        with torch.no_grad():
            ctxt_rgbd, trgt_rgbd, ctxt_feats = self.model.render_ctxt_from_trgt_cam(
                ctxt_rgb=inp["ctxt_rgb"],
                intrinsics=inp["intrinsics"],
                xy_pix=inp["x_pix"],
                ctxt_c2w=inp["ctxt_c2w"],
                trgt_c2w=inp["trgt_c2w"],
            )
            inp["trgt_rgbd"] = trgt_rgbd
            clean_ctxt_feats = ctxt_feats
            inp["clean_ctxt_feats"] = clean_ctxt_feats

        for t in tqdm(
            reversed(range(0, self.num_timesteps)),
            desc="sampling loop time step",
            total=self.num_timesteps,
        ):
            self_cond = x_start if self.self_condition else None
            inp["noisy_trgt_rgb"] = img

            img, x_start = self.p_sample(inp, t, self_cond)
            imgs.append(img)

        inp["noisy_trgt_rgb"] = img

        # ret = img if not return_all_timesteps else torch.stack(imgs, dim=1)
        # ret = self.unnormalize(ret)
        # return ret
        time_embed = torch.full((1,), t, device=device, dtype=torch.long)
        frames, depth_frames = self.model.render_video(
            inp, time_embed, 20, x_self_cond=False,
        )

        ret = img if not return_all_timesteps else torch.stack(imgs, dim=1)
        ret = self.unnormalize(ret)
        print("ret shape", ret.shape)
        rgb = None if trgt_rgbd is None else self.unnormalize(trgt_rgbd[:, :3, :, :])
        depth = None if trgt_rgbd is None else trgt_rgbd[:, 3:, :, :]
        out_dict = {
            "images": ret,
            "videos": frames,
            "rgb": rgb,
            "depth": depth,
            "depth_videos": depth_frames,
            "td_videos": td_frames,
            "td_depth_videos": td_depth_frames,
        }
        return out_dict

    @torch.no_grad()
    def ddim_sample(self, shape, return_all_timesteps=False, inp=None):
        batch, device, total_timesteps, sampling_timesteps, eta, objective = (
            shape[0],
            self.betas.device,
            self.num_timesteps,
            self.sampling_timesteps,
            self.ddim_sampling_eta,
            self.objective,
        )
        """Normalize input images"""
        times = torch.linspace(
            -1, total_timesteps - 1, steps=sampling_timesteps + 1
        )  # [-1, 0, 1, 2, ..., T-1] when sampling_timesteps == total_timesteps
        times = list(reversed(times.int().tolist()))
        time_pairs = list(
            zip(times[:-1], times[1:])
        )  # [(T-1, T-2), (T-2, T-3), ..., (1, 0), (0, -1)]
        temperature = 1.0  # 0.85
        img = torch.randn(shape, device=device) * temperature
        imgs = [img]
        x_start = None
        # """

        for time, time_next in tqdm(time_pairs, desc="sampling loop time step"):
            time_cond = torch.full((batch,), time, device=device, dtype=torch.long)
            self_cond = x_start if self.self_condition else None
            inp["noisy_trgt_rgb"] = img
            pred_noise, x_start, flow = self.model_predictions(
                inp,
                time_cond,
                x_self_cond=self_cond,
                clip_x_start=True,
                guidance_scale=self.guidance_scale,
            )
            if time_next < 0:
                img = x_start
                imgs.append(img)
                frames = self.model.render_video(
                    inp,
                    t=time_cond,
                    num_frames=20,
                    x_self_cond=False,
                    num_videos=shape[0],
                )
                continue
            alpha = self.alphas_cumprod[time]
            alpha_next = self.alphas_cumprod[time_next]
            sigma = (
                eta * ((1 - alpha / alpha_next) * (1 - alpha_next) / (1 - alpha)).sqrt()
            )
            c = (1 - alpha_next - sigma ** 2).sqrt()
            noise = torch.randn_like(img) * temperature
            img = x_start * alpha_next.sqrt() + c * pred_noise + sigma * noise
            imgs.append(img)

        inp["noisy_trgt_rgb"] = x_start
        print(f"final time_cond = {time_cond}")

        # _, _, flow = self.model_predictions(
        #     inp,
        #     time_cond,
        #     x_self_cond=self_cond,
        #     clip_x_start=True,
        #     guidance_scale=self.guidance_scale,
        # )

        ret = img if not return_all_timesteps else torch.stack(imgs, dim=1)
        ret = self.unnormalize(ret)
        out_dict = {
            "images": ret,
            "videos": frames,
            "flow": flow,
            "time_cond": time_cond,
        }
        return out_dict

    @torch.no_grad()
    def sample(self, batch_size=2, return_all_timesteps=False, inp=None):
        image_size, channels = self.image_size, self.channels
        sample_fn = (
            self.p_sample_loop if not self.is_ddim_sampling else self.ddim_sample
        )
        return sample_fn(
            (batch_size, channels, image_size, image_size),
            return_all_timesteps=return_all_timesteps,
            inp=inp,
        )

    @torch.no_grad()
    def interpolate(self, x1, x2, t=None, lam=0.5):
        b, *_, device = *x1.shape, x1.device
        t = default(t, self.num_timesteps - 1)

        assert x1.shape == x2.shape

        t_batched = torch.stack([torch.tensor(t, device=device)] * b)
        xt1, xt2 = map(lambda x: self.q_sample(x, t=t_batched), (x1, x2))

        img = (1 - lam) * xt1 + lam * xt2
        for i in tqdm(
            reversed(range(0, t)), desc="interpolation sample time step", total=t
        ):
            img = self.p_sample(
                img, torch.full((b,), i, device=device, dtype=torch.long)
            )

        return img

    def q_sample(self, x_start, t, noise=None):
        noise = default(noise, lambda: torch.randn_like(x_start))

        return (
            extract(self.sqrt_alphas_cumprod, t, x_start.shape) * x_start
            + extract(self.sqrt_one_minus_alphas_cumprod, t, x_start.shape) * noise
        )

    def edge_aware_smoothness(self, gt_img, flow, mask=None):
        bd, c, hd, wd = flow.shape

        gt_img = gt_img[:, 0]
        b, c, h, w = gt_img.shape
        assert bd == b and hd == h and wd == w

        flow = flow / (torch.mean(flow, dim=[2, 3], keepdim=True) + 1e-5)

        d_dx = torch.abs(flow[:, :, :, :-1] - flow[:, :, :, 1:])
        d_dy = torch.abs(flow[:, :, :-1, :] - flow[:, :, 1:, :])

        i_dx = torch.mean(
            torch.abs(gt_img[:, :, :, :-1] - gt_img[:, :, :, 1:]), 1, keepdim=True
        )
        i_dy = torch.mean(
            torch.abs(gt_img[:, :, :-1, :] - gt_img[:, :, 1:, :]), 1, keepdim=True
        )

        d_dx *= torch.exp(-i_dx)
        d_dy *= torch.exp(-i_dy)

        errors = F.pad(d_dx, pad=(0, 1), mode="constant", value=0) + F.pad(
            d_dy, pad=(0, 0, 0, 1), mode="constant", value=0
        )
        # print(f"errors shape: {errors.shape}")
        return errors

    @property
    def loss_fn(self):
        if self.loss_type == "l1":
            return F.l1_loss
        elif self.loss_type == "l2":
            return F.mse_loss
        else:
            raise ValueError(f"invalid loss type {self.loss_type}")

    def p_losses(self, inp, t, noise=None, render_video=False):
        num_target = inp["trgt_rgb"].shape[1]
        x_start = inp["trgt_rgb"][:, 0, ...]
        noise = default(noise, lambda: torch.randn_like(x_start))

        deterministic = True
        # noise sample
        x = self.q_sample(x_start=x_start, t=t, noise=noise)

        if self.deterministic:
            x = x * 0
            t *= 0

        # if doing self-conditioning, 50% of the time, predict x_start from current set of times
        # and condition with unet with that
        # this technique will slow down training by 25%, but seems to lower FID significantly
        x_self_cond = None
        if self.self_condition and random() < 0.5:
            with torch.no_grad():
                x_self_cond = self.model_predictions(x, t).pred_x_start
                x_self_cond.detach_()

        if self.use_guidance:
            uncond = random() > 0.9
            if uncond:
                # print("unconditional")
                inp["ctxt_rgb"] = inp["ctxt_rgb"] * 0.0

        # predict and take gradient step
        inp["noisy_trgt_rgb"] = x
        warped_imgs, flow, _, _ = self.model(
            inp, t, x_self_cond=x_self_cond, guidance_scale=1.0
        )  # no guidance during training

        frames = None
        if render_video:
            with torch.no_grad():
                frames = self.model.render_video(
                    inp, t=t, num_frames=20, x_self_cond=x_self_cond
                )

        if self.objective == "pred_noise":
            target = noise
        elif self.objective == "pred_x0":
            target = inp["trgt_rgb"]
        elif self.objective == "pred_v":
            v = self.predict_v(x_start, t, noise)
            target = v
        else:
            raise ValueError(f"unknown objective {self.objective}")

        # print(f"target shape = {target.shape}, warped_imgs shape = {warped_imgs.shape}")
        target = target.view(warped_imgs.shape)
        t = repeat(t, "b -> (b c)", c=num_target)

        loss = self.loss_fn(warped_imgs, target, reduction="none")
        loss = reduce(loss, "b ... -> b (...)", "mean")
        loss = loss * extract(self.p2_loss_weight, t, loss.shape)

        smooth_loss = self.edge_aware_smoothness(inp["ctxt_rgb"], flow)
        losses = {
            "rgb_loss": loss.mean(),
            "smooth_loss": smooth_loss.mean(),
        }
        return (
            losses,
            (
                self.unnormalize(x),
                self.unnormalize(inp["trgt_rgb"]),
                self.unnormalize(inp["ctxt_rgb"]),
                t,
                self.unnormalize(warped_imgs),
                flow,
                frames,
            ),
        )

    def forward(self, inp, *args, **kwargs):
        img = inp["trgt_rgb"][:, 0, ...]
        b, c, h, w, device, img_size, = *img.shape, img.device, self.image_size
        assert (
            h == img_size and w == img_size
        ), f"height and width of image must be {img_size}"
        t = torch.randint(0, self.num_timesteps, (b,), device=device).long()
        return self.p_losses(inp, t, *args, **kwargs)


# trainer class
class Trainer(object):
    def __init__(
        self,
        diffusion_model,
        dataloader=None,
        train_batch_size=16,
        gradient_accumulate_every=1,
        augment_horizontal_flip=True,
        train_lr=1e-4,
        train_num_steps=100000,
        ema_update_every=10,
        ema_decay=0.995,
        adam_betas=(0.9, 0.99),
        sample_every=1000,
        wandb_every=100,
        save_every=1000,
        num_samples=25,
        # results_folder="./results",
        amp=False,
        fp16=False,
        split_batches=True,
        warmup_period=0,
        checkpoint_path=None,
        wandb_config=None,
        run_name="diffusion",
        dist_loss_weight=0.0,
        smooth_loss_weight=0.0,
        cfg=None,
    ):
        super().__init__()

        ddp_kwargs = DistributedDataParallelKwargs(find_unused_parameters=True)
        self.accelerator = Accelerator(
            split_batches=split_batches,
            mixed_precision="fp16" if fp16 else "no",
            kwargs_handlers=[ddp_kwargs],
        )

        self.accelerator.native_amp = amp

        self.model = diffusion_model

        # assert has_int_squareroot(
        #     num_samples
        # ), "number of samples must have an integer square root"
        self.num_samples = num_samples
        self.sample_every = sample_every
        self.save_every = save_every
        self.wandb_every = wandb_every
        self.dist_loss_weight = dist_loss_weight
        self.smooth_loss_weight = smooth_loss_weight

        assert self.sample_every % self.wandb_every == 0

        self.batch_size = train_batch_size
        print(f"batch size: {self.batch_size}")
        self.gradient_accumulate_every = gradient_accumulate_every

        self.train_num_steps = train_num_steps
        # self.image_size = diffusion_model.image_size

        # dataset and dataloader

        self.dataloader = self.accelerator.prepare(dataloader)
        self.dl = cycle(self.dataloader)

        # optimizer

        self.opt = Adam(diffusion_model.parameters(), lr=train_lr, betas=adam_betas)
        lr_scheduler = get_cosine_schedule_with_warmup(
            self.opt, warmup_period, train_num_steps
        )
        if self.accelerator.is_main_process:
            self.ema = EMA(
                diffusion_model, beta=ema_decay, update_every=ema_update_every
            )

        self.step = 0
        if checkpoint_path is None and cfg.resume_id is not None:
            folders = [
                os.path.join("wandb/", f, "files")
                for f in sorted(os.listdir("wandb"))
                if cfg.resume_id in f
            ]
            # find all *.pt files in all folders
            ckpt_files = []
            for folder in folders:
                ckpt_files.extend(
                    [
                        os.path.join(folder, f)
                        for f in os.listdir(folder)
                        if f.endswith(".pt")
                    ]
                )
            # find the latest checkpoint
            checkpoint_path = sorted(ckpt_files)[-1]

        # prepare model, dataloader, optimizer with accelerator
        if checkpoint_path is not None and self.accelerator.is_main_process:
            load = self.load(checkpoint_path)
            # load = self.load_highres_from_lowres(checkpoint_path)
            # self.load_viewdep_from_noviewdep(checkpoint_path)
            # self.load_fine_from_coarse(checkpoint_path)
            # self.load_from_pixelnerf(checkpoint_path)
            # self.load_from_external_checkpoint(checkpoint_path)

        # self.model, self.opt, self.lr_scheduler = self.accelerator.prepare(
        #     self.model, self.opt, lr_scheduler
        # )
        # separate the previous line into 3 lines
        self.opt = self.accelerator.prepare(self.opt)
        self.lr_scheduler = self.accelerator.prepare(lr_scheduler)

        self.model = self.accelerator.prepare(self.model)

        if self.accelerator.is_main_process:
            if cfg.wandb_id is not None:
                run = wandb.init(
                    config=cfg, **wandb_config, id=cfg.wandb_id, resume="allow"
                )
            elif cfg.resume_id is not None:
                run = wandb.init(
                    config=cfg, **wandb_config, id=cfg.resume_id, resume="must"
                )
            else:
                run = wandb.init(config=cfg, **wandb_config)
            # print(f"starting run {cfg.wandb_id}")
            wandb.run.log_code(".")
            wandb.run.name = run_name
            print(f"run dir: {run.dir}", flush=True)
            run_dir = run.dir
            wandb.save(os.path.join(run_dir, "checkpoint*"))
            wandb.save(os.path.join(run_dir, "video*"))
            self.results_folder = Path(run_dir)
            self.results_folder.mkdir(exist_ok=True)

    def save(self, milestone):
        if not self.accelerator.is_local_main_process:
            return

        data = {
            "step": self.step,
            "model": self.accelerator.get_state_dict(self.model),
            "opt": self.opt.state_dict(),
            "ema": self.ema.state_dict(),
            "scaler": self.accelerator.scaler.state_dict()
            if exists(self.accelerator.scaler)
            else None,
            "version": __version__,
        }
        torch.save(data, str(self.results_folder / f"model-{milestone}.pt"))
        wandb.save(
            str(self.results_folder / f"model-{milestone}.pt"),
            base_path=self.results_folder,
        )
        # delete prev checkpoint if exists
        prev_milestone = milestone - 1
        prev_path = self.results_folder / f"model-{prev_milestone}.pt"
        if os.path.exists(prev_path):
            # delete prev checkpoint
            os.remove(prev_path)

    def load(self, path):
        accelerator = self.accelerator
        device = accelerator.device

        data = torch.load(
            # str(self.results_folder / f"model-{milestone}.pt"), map_location=device
            str(path),
            map_location=torch.device("cpu"),
        )

        # model = self.accelerator.unwrap_model(self.model)
        model = self.model
        # print(f"model parameter names: {list(model.state_dict().keys())}")
        model.load_state_dict(data["model"], strict=True)

        self.step = data["step"]
        # self.opt.load_state_dict(data["opt"])

        if self.accelerator.is_main_process:
            self.ema.load_state_dict(data["ema"], strict=True)

        if "version" in data:
            print(f"loading from version {data['version']}")

        if exists(self.accelerator.scaler) and exists(data["scaler"]):
            self.accelerator.scaler.load_state_dict(data["scaler"])

        del data

    def load_highres_from_lowres(self, path):
        accelerator = self.accelerator
        device = accelerator.device

        data = torch.load(str(path), map_location=torch.device("cpu"))

        new_state_dict = OrderedDict()
        for key, value in data["model"].items():
            if "enc.pos_embed" not in key:
                new_state_dict[key] = value

        model = self.model
        model.load_state_dict(new_state_dict, strict=False)

        self.step = data["step"]

        if self.accelerator.is_main_process:
            new_state_dict = OrderedDict()
            for key, value in data["ema"].items():
                if "enc.pos_embed" not in key:
                    new_state_dict[key] = value

            self.ema.load_state_dict(new_state_dict, strict=False)

        if "version" in data:
            print(f"loading from version {data['version']}")

        if exists(self.accelerator.scaler) and exists(data["scaler"]):
            self.accelerator.scaler.load_state_dict(data["scaler"])

        del data

    def load_viewdep_from_noviewdep(self, path):
        accelerator = self.accelerator
        device = accelerator.device

        data = torch.load(str(path), map_location=torch.device("cpu"))

        new_state_dict = OrderedDict()
        for key, value in data["model"].items():
            if "pos_embed" not in key:
                new_state_dict[key] = value

        model = self.model
        model.load_state_dict(new_state_dict, strict=False)

        self.step = data["step"]

        if self.accelerator.is_main_process:
            new_state_dict = OrderedDict()
            for key, value in data["ema"].items():
                if "pos_embed" not in key:
                    new_state_dict[key] = value

            self.ema.load_state_dict(new_state_dict, strict=False)

        if "version" in data:
            print(f"loading from version {data['version']}")

        if exists(self.accelerator.scaler) and exists(data["scaler"]):
            self.accelerator.scaler.load_state_dict(data["scaler"])

        del data

    def load_fine_from_coarse(self, path):
        accelerator = self.accelerator
        device = accelerator.device

        data = torch.load(str(path), map_location=torch.device("cpu"))

        new_state_dict = OrderedDict()
        for key, value in data["model"].items():
            if "pixelNeRF_joint.mlp" in key:
                new_state_dict[key] = value
                new_state_dict[
                    key.replace("pixelNeRF_joint.mlp", "pixelNeRF_joint.mlp_fine")
                ] = value
            else:
                new_state_dict[key] = value
        model = self.model
        model.load_state_dict(new_state_dict, strict=False)

        self.step = data["step"]

        if self.accelerator.is_main_process:
            new_state_dict = OrderedDict()
            for key, value in data["ema"].items():
                if "pixelNeRF_joint.mlp" in key:
                    new_state_dict[key] = value
                    new_state_dict[
                        key.replace("pixelNeRF_joint.mlp", "pixelNeRF_joint.mlp_fine")
                    ] = value
                else:
                    new_state_dict[key] = value

            self.ema.load_state_dict(new_state_dict, strict=False)

        if "version" in data:
            print(f"loading from version {data['version']}")

        if exists(self.accelerator.scaler) and exists(data["scaler"]):
            self.accelerator.scaler.load_state_dict(data["scaler"])

        del data

    def load_from_pixelnerf(self, path):
        accelerator = self.accelerator
        device = accelerator.device

        model = self.accelerator.unwrap_model(self.model)
        data = torch.load(path, map_location=device)

        new_state_dict = OrderedDict()
        for key, value in data["model"].items():
            if "pixel" in key:
                new_state_dict[key.replace("pixelNeRF", "pixelNeRF_joint")] = value
                new_state_dict[key] = value
            elif "enc" in key:
                if "enc.model.conv1" not in key:
                    new_state_dict[key.replace("enc", "noisy_trgt_enc")] = value
                new_state_dict[key] = value
            elif key in model.state_dict().keys():
                new_state_dict[key] = value
            else:
                print(f"key {key} not in model state dict")
        # exit()
        model.load_state_dict(new_state_dict, strict=False)

    def load_from_external_checkpoint(self, path):
        accelerator = self.accelerator
        device = accelerator.device

        model = self.accelerator.unwrap_model(self.model)
        data = torch.load(path, map_location=device)

        from collections import OrderedDict

        new_state_dict = OrderedDict()
        for key, value in data["model_state_dict"].items():
            if "enc" not in key:
                key = "model." + key[7:]  # remove `att.`
                new_state_dict[key] = value
                if key not in model.state_dict().keys():
                    print(f"enc key {key} not in model state dict")
            else:
                new_key = "model." + key[7:]  # remove `att.`
                key1 = new_key.replace(".enc.", ".clean_ctxt_enc.")
                new_key.replace(".enc.", ".noisy_trgt_enc.")
                new_state_dict[key1] = value

                if key1 not in model.state_dict().keys():
                    print(f"key {key1} not in model state dict")
        model.load_state_dict(new_state_dict, strict=False)

    def train(self):
        accelerator = self.accelerator
        device = accelerator.device

        torch.cuda.set_device(device)
        print(f"device: {device}")
        torch.cuda.empty_cache()

        with tqdm(
            initial=self.step,
            total=self.train_num_steps,
            disable=not accelerator.is_main_process,
        ) as pbar:

            while self.step < self.train_num_steps:

                total_loss = 0.0
                total_rgb_loss = 0.0
                total_rgb_cond_loss = 0.0
                total_smooth_loss = 0.0
                total_dist_loss = 0.0
                render_video = (
                    self.step % self.wandb_every == 0
                )  # and accelerator.is_main_process

                for _ in range(self.gradient_accumulate_every):
                    # if accelerator.is_main_process:
                    # self.dataloader.dataset.num_context = np.random.randint(
                    #     1, self.dataloader.dataset.max_num_context + 1
                    # )
                    # print(
                    #     f"num_context main: {self.dataloader.dataset.num_context}"
                    # )
                    num_context = np.random.randint(1, 4,)
                    data = next(self.dl)  # .to(device)
                    if isinstance(data, list):
                        # gt = data[1]
                        data = data[0]
                        for k, v in data.items():
                            if k in ["ctxt_rgb", "ctxt_c2w"]:
                                data[k] = v[:, :num_context]
                        data = to_gpu(data, device)

                    with self.accelerator.autocast():
                        losses, misc = self.model(data, render_video=render_video)
                        # print("losses computed")
                        rgb_loss = losses["rgb_loss"]
                        rgb_loss = rgb_loss / self.gradient_accumulate_every
                        total_rgb_loss += rgb_loss.item()

                        smooth_loss = losses["smooth_loss"]
                        smooth_loss = smooth_loss / self.gradient_accumulate_every
                        total_smooth_loss += smooth_loss.item()

                        loss = rgb_loss + self.smooth_loss_weight * smooth_loss
                        total_loss += loss.item()

                    self.accelerator.backward(loss)  # TODO check if this is correct
                    # print("loss backwarded")
                if accelerator.is_main_process:
                    wandb.log(
                        {
                            "loss": total_loss,
                            "rgb_loss": total_rgb_loss,
                            "smooth_loss": total_smooth_loss,
                            "lr": self.lr_scheduler.get_last_lr()[0],
                            "num_context": data["ctxt_rgb"].shape[1],
                        },
                        step=self.step,
                    )

                accelerator.clip_grad_norm_(self.model.parameters(), 1.0)
                pbar.set_description(f"loss: {total_loss:.4f}")

                accelerator.wait_for_everyone()
                # print(f"device: {device}")
                self.opt.step()
                self.opt.zero_grad()

                accelerator.wait_for_everyone()

                all_images = None
                all_videos_list = None
                all_flow_list = None
                all_rgb = None
                all_flows = None
                if accelerator.is_main_process:  # or not accelerator.is_main_process:
                    # self.ema.to(device)
                    self.ema.update()

                    if self.step != 0 and self.step % self.sample_every == 0:
                        self.ema.ema_model.eval()

                        with torch.no_grad():
                            milestone = self.step // self.sample_every
                            batches = num_to_groups(self.num_samples, self.batch_size)
                            print(f"batch sizes: {batches}")
                            # batches = num_to_groups(self.num_samples, 2)
                            def sample(n):
                                data.update((k, v[:n]) for k, v in data.items())
                                return self.ema.ema_model.sample(batch_size=n, inp=data)
                                # return self.model.module.sample(batch_size=n, inp=data)

                            output_dict_list = list(map(lambda n: sample(n), batches,))
                            all_images_list = [o["images"] for o in output_dict_list]
                            all_videos_list = [o["videos"] for o in output_dict_list]
                            all_flow_list = [o["flow"] for o in output_dict_list]
                            # all_videos_list = [o["videos"] for o in output_dict_list]
                            all_rgb = (
                                None
                                # if output_dict_list[0]["rgb"] is None
                                # else [o["rgb"] for o in output_dict_list]
                            )
                            # accelerator.wait_for_everyone()
                        all_images = torch.cat(all_images_list, dim=0)
                        all_flows = torch.cat(all_flow_list, dim=0)
                        all_rgb = None if all_rgb is None else torch.cat(all_rgb, dim=0)
                        if accelerator.is_main_process:
                            utils.save_image(
                                all_images,
                                str(self.results_folder / f"sample-{milestone}.png"),
                                nrow=int(math.sqrt(self.num_samples)),
                            )

                    if (
                        self.step % self.wandb_every == 0
                        and accelerator.is_main_process
                    ):
                        self.wandb_summary(
                            all_images, all_rgb, misc, all_videos_list, all_flows
                        )

                        if self.step != 0 and self.step % self.save_every == 0:
                            milestone = self.step // self.save_every
                            self.save(milestone)
                            print(f"saved model at {milestone} milestones")

                self.step += 1

                # if self.warmup_step is not None:
                #     self.warmup_step()
                self.lr_scheduler.step()
                # wandb.log({"lr": self.lr_scheduler.get_last_lr()[0]}, step=self.step)
                # print(f"lr: {self.lr_scheduler.get_last_lr()}")
                pbar.update(1)

        accelerator.print("training complete")

    def wandb_summary(self, all_images, all_rgb, misc, sampled_videos, sampled_flows):
        print("wandb summary")
        (input, t_gt, ctxt_rgb, t, output, flow, frames) = misc
        log_dict = {
            "sanity/denoised_min": output.min(),
            "sanity/denoised_max": output.max(),
            "sanity/noisy_input_min": input.min(),
            "sanity/noisy_input_max": input.max(),
            "sanity/ctxt_rgb_min": ctxt_rgb.min(),
            "sanity/ctxt_rgb_max": ctxt_rgb.max(),
            "sanity/flow_min": flow.min(),
            "sanity/flow_max": flow.max(),
            "sanity/flow_mean": flow.mean(),
            "sanity/flow_std": flow.std(),
        }
        t_gt = rearrange(t_gt, "b t c h w -> (b t) c h w")
        ctxt_rgb = rearrange(ctxt_rgb, "b t c h w -> (b t) c h w")
        # print(f"t_gt shape: {t_gt.shape}, output shape: {output.shape}")
        # exit()
        # b, c, h, w = t_gt.shape

        input = torch.clamp(input, 0, 1)
        output = torch.clamp(output, 0, 1)
        t_gt = torch.clamp(t_gt, 0, 1)
        ctxt_rgb = torch.clamp(ctxt_rgb, 0, 1)

        def prepare_flows(flows):
            new_flows = []
            for i in range(min(flows.shape[0], 10)):
                flow = flows[i]
                flow = flow_vis.flow_to_color(
                    flow.permute(1, 2, 0).cpu().detach().numpy(), convert_to_bgr=False
                )
                new_flows.append(flow)
            new_flows = torch.from_numpy(np.array(new_flows))
            new_flows = make_grid(new_flows.permute(0, 3, 1, 2))
            new_flows = new_flows.type(torch.float32) / 255.0
            new_flows = wandb.Image(new_flows)
            return new_flows

        # rendered_ctxt_depths = prepare_depths(rendered_ctxt_depth)
        image_dict = {
            "visualization/noisy_input": wandb.Image(
                make_grid(input[:10].cpu().detach()).permute(1, 2, 0).numpy()
            ),
            "result/output": wandb.Image(
                make_grid(output[:20].cpu().detach()).permute(1, 2, 0).numpy()
            ),
            "result/target": wandb.Image(
                make_grid(t_gt[:20].cpu().detach()).permute(1, 2, 0).numpy()
            ),
            "result/ctxt_rgb": wandb.Image(
                make_grid(ctxt_rgb[:10].cpu().detach()).permute(1, 2, 0).numpy()
            ),
            "visualization/flow": prepare_flows(flow[:]),
        }

        if all_images is not None:
            log_dict.update(
                {
                    "sanity/sample_min": all_images.min(),
                    "sanity/sample_max": all_images.max(),
                }
            )
            images = make_grid(all_images.cpu().detach())
            images = wandb.Image(images.permute(1, 2, 0).numpy())
            image_dict.update({"visualization/samples": images})
            if all_rgb is not None:
                rgb = make_grid(all_rgb.cpu().detach())
                rgb = wandb.Image(rgb.permute(1, 2, 0).numpy())
                image_dict.update({"visualization/rgb": rgb})

            image_dict.update(
                {"visualization/sampled_flows": prepare_flows(sampled_flows[:])}
            )

        wandb.log(log_dict)
        wandb.log(image_dict)

        run_dir = wandb.run.dir
        for f in range(len(frames)):
            frames[f] = rearrange(frames[f], "b h w c -> h (b w) c")

        denoised_f = os.path.join(run_dir, "denoised_view_circle.mp4")
        imageio.mimwrite(denoised_f, frames, fps=8, quality=7)
        wandb.log(
            {"vid/denoised": wandb.Video(denoised_f, format="mp4", fps=8),}
        )

        if sampled_videos is not None:
            for f in range(len(sampled_videos[0])):
                sampled_videos[0][f] = rearrange(
                    sampled_videos[0][f], "b h w c -> h (b w) c"
                )
            sampled_f = os.path.join(run_dir, "sampled_view_circle.mp4")
            imageio.mimwrite(sampled_f, sampled_videos[0], fps=8, quality=7)
            wandb.log(
                {"vid/sampled": wandb.Video(sampled_f, format="mp4", fps=8),}
            )

        print(f"end wandb summary sample")
