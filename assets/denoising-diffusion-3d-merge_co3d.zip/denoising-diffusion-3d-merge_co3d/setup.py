from setuptools import setup, find_packages

setup(
    name="denoising-diffusion3d",
    version="0.0.1",
    packages=find_packages(),
)