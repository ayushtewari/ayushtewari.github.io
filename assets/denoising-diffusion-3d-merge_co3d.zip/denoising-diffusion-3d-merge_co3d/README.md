# Diffusion with Forward Models: Solving Stochastic Inverse Problems Without Direct Supervision

## Abstract 

Denoising diffusion models have emerged as a powerful class of generative models
capable of capturing the distributions of complex, real-world signals. However,
current approaches can only model distributions for which training samples are
directly accessible, which is not the case in many real-world tasks. In inverse
graphics, for instance, we seek to sample from a distribution over 3D scenes
consistent with an image but do not have access to ground-truth 3D scenes, only
2D images. We present a new class of conditional denoising diffusion probabilistic
models that learn to sample from distributions of signals that are never observed
directly, but instead are only measured through a known differentiable forward
model that generates partial observations of the unknown signal. To accomplish
this, we directly integrate the forward model into the denoising process. At test
time, our approach enables us to sample from the distribution over underlying
signals consistent with some partial observation. We demonstrate the efficacy of
our approach on three challenging computer vision tasks. For instance, in inverse
graphics, we demonstrate that our model in combination with a 3D-structured
conditioning method enables us to directly sample from the distribution of 3D
scenes consistent with a single 2D input image.

## Usage 

### Environment Setup 


```bash
conda create -n test python=3.9 -y 
conda activate test 
pip install torch==2.0.1 torchvision
conda install -y -c fvcore -c iopath -c conda-forge fvcore iopath 
pip install --no-index --no-cache-dir pytorch3d -f https://dl.fbaipublicfiles.com/pytorch3d/packaging/wheels/py39_cu117_pyt201/download.html
pip install -r requirements.txt
python setup.py develop
```

### Prepare CO3D 

```bash 
python data_io/co3d_new.py --prepare_dataset --dataset_root CO3D_ROOT 
```

### CO3D Inference 

```bash
python experiment_scripts/co3d_results.py dataset=CO3D name=debug_co3d_oneshot_debug_new_branch ngpus=1 feats_cond=True wandb=online checkpoint_path=/home/tianweiy/Projects/denoising-diffusion-3d/downloaded_checkpoints/co3d_pose_conditioning_more_coarse/model-612_modified_ema.pt use_abs_pose=True sampling_type=oneshot use_dataset_pose=True

```

### CO3D Training

```bash 
# first train two-view pixelnerf  
torchrun  --nnodes 1 --nproc_per_node 6   experiment_scripts/train_pixelnerf.py dataset=CO3D name=reproduce_pn_2ctxt  num_context=2 num_target=2 lr=2e-5 batch_size=12  wandb=online use_abs_pose=true scale_aug_ratio=0.2

# train diffusion with pn initialization 
python experiment_scripts/train_3D_diffusion.py use_abs_pose=True dataset=CO3D lr=2e-5 ngpus=8 setting_name=co3d_3ctxt_more_coarse feats_cond=True wandb=online dataset.lpips_loss_weight=0.2 name=co3d_pose_conditioning_more_coarse scale_aug_ratio=0.2 checkpoint_path=  all_class=False

# generate camera quality score again 
python data_io/co3d_new.py --generate_camera_quality_file --dataset_root ROOT

# train 10 class co3d 
torchrun  --nnodes 1 --nproc_per_node 8 experiment_scripts/train_3D_diffusion.py use_abs_pose=True dataset=CO3D lr=2e-5 ngpus=8 setting_name=co3d_3ctxt_more_coarse feats_cond=True wandb=online dataset.lpips_loss_weight=0.2 name=co3d_3ctxt_more_coarse_10class scale_aug_ratio=0.2  all_class=True checkpoint_path="/home/tianweiy/Projects/denoising-diffusion-3d/downloaded_checkpoints/co3d_pose_conditioning_more_coarse/model-612_modified_ema.pt" ema_decay=0.9


# train hydrant with 5% pose noise 
torchrun  --nnodes 1 --nproc_per_node 2 experiment_scripts/train_3D_diffusion.py use_abs_pose=True dataset=CO3D lr=2e-5 ngpus=2 setting_name=co3d_3ctxt_more_coarse feats_cond=True wandb=online dataset.lpips_loss_weight=0.2 name=co3d_3ctxt_more_coarse_hydrant_noise scale_aug_ratio=0.2  all_class=False checkpoint_path="/home/tianweiy/Projects/denoising-diffusion-3d/downloaded_checkpoints/co3d_pose_conditioning_more_coarse/model-612_modified_ema.pt" ema_decay=0.9  noise=0.05

```