# /usr/bin/env python
# Copyright (c) 2018, Ruohan Gao
# All rights reserved.

import os
import argparse
import random
import numpy as np
from scipy import misc
import math
import skimage.measure
import heapq
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import matplotlib.cm as cm
import matplotlib.colors as mcolors
import matplotlib.colorbar as mcolorbar
import PIL
from PIL import Image


def visualizeFlow(img, flow, out_path):
    # parser = argparse.ArgumentParser()
    # parser.add_argument('--flowImgInputDir', type=str, required=True)
    # parser.add_argument('--rgbImgDir', type=str, required=True)
    # parser.add_argument('--blockSize', type=int, default=8)
    # parser.add_argument('--arrowImgOutDir', type=str)
    # args = parser.parse_args()
    # flowImgs = sorted(os.listdir(args.flowImgInputDir))
    # if not os.path.isdir(args.arrowImgOutDir):
    #     os.mkdir(args.arrowImgOutDir)

    blockSize = 8

    # set plots
    fig, ax = plt.subplots(1, 1)
    plt.axis("off")
    ax.axes.get_xaxis().set_visible(False)
    ax.axes.get_yaxis().set_visible(False)
    nz = mcolors.Normalize(0.0, 2 * np.pi)

    # img_name = img_name.strip()
    # print 'Visualizing flow for ', img_name
    # predicted_flow = misc.imread(os.path.join(args.flowImgInputDir, img_name))
    # predicted_xy = np.empty([predicted_flow.shape[0], predicted_flow.shape[1], 2])
    #
    # flow are normalized and encoded in an image
    # convert back to original scale sin,cos,mgt
    # predicted_mgt = predicted_flow[:,:,2] / 255.0 * 30
    # predicted_sin = predicted_flow[:,:,0] / 255.0 * 2 - 1
    # predicted_cos = predicted_flow[:,:,1] / 255.0 * 2 - 1

    # convert back to flow
    # predicted_xy[:,:,0] = predicted_cos * predicted_mgt
    # minus sign because y-axis is reversed for displaying
    # predicted_xy[:,:,1] = -predicted_sin * predicted_mgt

    # block-wise average flow prediction
    downsampled_predicted_xy = skimage.measure.block_reduce(
        flow, (blockSize, blockSize, 1), np.mean
    )
    downsampled_mgt = np.sqrt(
        np.square(downsampled_predicted_xy[:, :, 0])
        + np.square(downsampled_predicted_xy[:, :, 1])
    )

    # im = Image.open(os.path.join(args.rgbImgDir, img_name))
    print(f"img.shape: {img.shape}")
    im = Image.fromarray((img * 255).astype(np.uint8))
    # im = img
    im = im.point(lambda p: p)
    # im.save(os.path.join(args.arrowImgOutDir, img_name))
    # input_image = misc.imresize(misc.imread(os.path.join(args.arrowImgOutDir, img_name)), predicted_flow.shape)

    # find a suitable threshold for visulization
    flatten_mgt = downsampled_mgt.flatten()
    largeNIndex = heapq.nlargest(200, range(len(flatten_mgt)), flatten_mgt.take)
    threshold = flatten_mgt[largeNIndex[-1]]
    print(f"threshold: {threshold}, max: {np.max(flatten_mgt)}")
    # plot arrows
    input_image = np.array(img)
    ax.imshow(input_image)
    # quiver statistics
    X = []
    Y = []
    U = []
    V = []
    print(
        f"downsampled_mgt.shape: {downsampled_mgt.shape}, input_image.shape: {input_image.shape}, blockSize: {blockSize}"
    )
    for i in range(input_image.shape[0] // blockSize):
        for j in range(input_image.shape[1] // blockSize):
            if downsampled_mgt[i, j] >= threshold:
                Y.append(i * blockSize + blockSize / 2)
                X.append(j * blockSize + blockSize / 2)
                U.append(downsampled_predicted_xy[i, j, 0])
                V.append(downsampled_predicted_xy[i, j, 1])

    # negate to make the color agree with the color wheel
    angle = np.arctan2(np.negative(V), np.negative(U)) + np.pi
    ax.quiver(
        X,
        Y,
        U,
        V,
        angles="uv",
        units="xy",
        color=cm.hsv(nz(angle)),
        pivot="mid",
        scale=0.05,
    )
    # out_path = os.path.join(out_folder, "flowviz.png")
    plt.savefig(out_path, bbox_inches="tight", pad_inches=0)
    plt.cla()
    plt.close()
    # read image
    img = Image.open(out_path)
    # resize to 64x64
    img = img.resize((64, 64), PIL.Image.ANTIALIAS)

    print(np.array(img).shape)
    # exit()
    # to numpy
    img = np.array(img).astype(np.float32) / 255.0
    return img[:, :, :3]
