import torch, torchvision
from torch import nn, einsum
import torch.nn.functional as F
import sys
import os
import numpy as np
import functools
from einops import rearrange, repeat

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from PixelNeRF.pixelnerf_helpers import *
from PixelNeRF.view_interpolation import interpolate_pose
from PixelNeRF.transformer.DiT import DiT
from PixelNeRF.transformer.uvit import UViT
from Flow import softsplat as softsplat

from PixelNeRF.pixelnerf_model_cond import RefineOut


class FlowModel(nn.Module):
    def __init__(
        self,
        model="dit",
        viz_type="spherical",
        channels=3,
        use_first_pool=True,
        feats_cond=False,
        use_high_res_feats=False,
        use_viewdir=False,
        image_size=128,
    ):
        super().__init__()
        self.model = model
        print("model", model)
        self.feats_cond = feats_cond
        self.image_size = image_size

        if model == "resnet":
            self.enc = PixelNeRFTimeEmbed(
                block=BasicBlockTimeEmbed,
                layers=[3, 4, 6, 3],
                use_first_pool=use_first_pool,
                use_viewdir=use_viewdir,
            )
        elif model == "dit":
            self.enc = DiT(
                depth=28,
                input_size=(image_size // 2, image_size // 2),
                hidden_size=1152,
                patch_size=2,
                num_heads=16,
                in_channels=64,
                out_channels=2,
                cond_feats_dim=0,  #   128 if feats_cond else 4,
                use_high_res=use_high_res_feats,
            )
        elif model == "uvit":
            self.enc = UViT(
                dim=128,
                out_dim=512,
                cond_feats_dim=self.n_feats_out,
                use_high_res=use_high_res_feats,
            )

        self.cnn_refine = False
        if self.cnn_refine:
            self.cnn_refine_model = RefineOut(in_channels=3, out_channels=3)
        self.channels = channels
        self.out_dim = channels
        self.self_condition = False
        self.normalize = normalize_to_neg_one_to_one
        self.unnormalize = unnormalize_to_zero_to_one
        self.viz_type = viz_type

    def get_feats(self, inp, t):
        if self.model == "resnet":
            latent = self.enc(inp, time_emb=t)
        elif self.model == "dit":
            latent = self.enc(inp, t=t)
        elif self.model == "uvit":
            latent = self.enc(inp, time=t)
        # return latent * 8.0
        return latent * 16.0

    # @torch.no_grad()

    def forward(self, model_input, t, guidance_scale=1.0, x_self_cond=None):
        ctxt_img = model_input["ctxt_rgb"][:, 0]
        trgt_img = model_input["noisy_trgt_rgb"]

        # print(f"ctxt_img.shape: {ctxt_img.shape}, trgt_img.shape: {trgt_img.shape}")
        trgt_inp = torch.cat([ctxt_img, trgt_img], dim=1)
        flow = self.get_feats(trgt_inp, t)

        b, c, h, w = ctxt_img.shape
        disable_sample = False
        flow_for_warp = flow

        num_trgt = model_input["trgt_rgb"].shape[1]
        if num_trgt > 1:
            if not disable_sample:
                mid = softsplat.softsplat(
                    tenIn=model_input["ctxt_rgb_nonzero"][:, 0],
                    tenFlow=flow_for_warp * 0.5,
                    tenMetric=None,
                    strMode="avg",
                )
            else:
                mid = model_input["trgt_rgb"][:, 1]

        if not disable_sample:
            end = softsplat.softsplat(
                tenIn=model_input["ctxt_rgb_nonzero"][:, 0],
                tenFlow=flow_for_warp,
                tenMetric=None,
                strMode="avg",
            )
        else:
            end = model_input["trgt_rgb"][:, 0]

        if num_trgt > 1:
            warped_imgs = torch.cat([end.unsqueeze(1), mid.unsqueeze(1)], dim=1)
        else:
            warped_imgs = end.unsqueeze(1)

        warped_imgs = rearrange(warped_imgs, "b t c h w -> (b t) c h w")
        if self.cnn_refine:
            warped_imgs = self.cnn_refine_model(warped_imgs)

        uncond_warped_imgs = None
        uncond_flow = None
        if guidance_scale > 1.0:
            ctxt_img *= 0

            trgt_inp = torch.cat([ctxt_img, trgt_img], dim=1)
            uncond_flow = self.get_feats(trgt_inp, t)
            b, c, h, w = ctxt_img.shape
            disable_sample = False
            flow_for_warp = uncond_flow

            num_trgt = model_input["trgt_rgb"].shape[1]
            if num_trgt > 1:
                if not disable_sample:
                    mid = softsplat.softsplat(
                        tenIn=model_input["ctxt_rgb_nonzero"][:, 0],
                        tenFlow=flow_for_warp * 0.5,
                        tenMetric=None,
                        strMode="avg",
                    )
                else:
                    mid = model_input["trgt_rgb"][:, 1]

            if not disable_sample:
                end = softsplat.softsplat(
                    tenIn=model_input["ctxt_rgb_nonzero"][:, 0],
                    tenFlow=flow_for_warp,
                    tenMetric=None,
                    strMode="avg",
                )
            else:
                end = model_input["trgt_rgb"][:, 0]

            if num_trgt > 1:
                uncond_warped_imgs = torch.cat(
                    [end.unsqueeze(1), mid.unsqueeze(1)], dim=1
                )
            else:
                uncond_warped_imgs = end.unsqueeze(1)

            uncond_warped_imgs = rearrange(
                uncond_warped_imgs, "b t c h w -> (b t) c h w"
            )
            if self.cnn_refine:
                uncond_warped_imgs = self.cnn_refine_model(uncond_warped_imgs)

        return warped_imgs, flow, uncond_warped_imgs, uncond_flow

    # def vid_from_flow(self, flow, model_input):
    #     b, c, h, w = flow.shape
    #     x_pix = model_input["x_pix"]
    #     grid = x_pix.view(b, h, w, 2)
    #
    #     ctxt_img = model_input["ctxt_rgb"][:, 0]
    #     # generate multiple warped images with different weights
    #     warped_imgs = []
    #     N = 20
    #     for i in range(N):
    #         flow_grid = grid + flow.permute(0, 2, 3, 1) * i / N
    #         flow_grid[..., 0] = (flow_grid[..., 0]) * 2 - 1
    #         flow_grid[..., 1] = (flow_grid[..., 1]) * 2 - 1
    #         warped_img = F.grid_sample(ctxt_img, flow_grid, padding_mode="zeros")
    #         warped_imgs.append(warped_img)
    #     return warped_imgs

    def render_video(
        self, model_input, t, x_self_cond=None, num_frames=20, num_videos=10
    ):
        ctxt_img = model_input["ctxt_rgb_nonzero"][:, 0]
        trgt_img = model_input["noisy_trgt_rgb"]

        ctxt_img = ctxt_img[:num_videos]
        trgt_img = trgt_img[:num_videos]
        t = t[:num_videos]

        trgt_inp = torch.cat([ctxt_img, trgt_img], dim=1)
        flow = self.get_feats(trgt_inp, t)

        b, c, h, w = ctxt_img.shape
        flow_for_warp = flow

        t = torch.linspace(0, 1.0, num_frames).to(flow.device)
        frames = []
        for i in range(num_frames):
            rgb = softsplat.softsplat(
                tenIn=ctxt_img,
                tenFlow=flow_for_warp * t[i],
                tenMetric=None,
                strMode="avg",
            )
            rgb = rearrange(rgb, "b c h w -> b h w c")
            rgb = self.unnormalize(rgb) * 255.0
            frames.append(rgb.float().cpu().detach().numpy().astype(np.uint8))

        return frames
        # mid = softsplat.softsplat(
        #     tenIn=ctxt_img, tenFlow=flow_for_warp * 0.5, tenMetric=None, strMode="avg"
        # )
        # end = softsplat.softsplat(
        #     tenIn=ctxt_img, tenFlow=flow_for_warp, tenMetric=None, strMode="avg"
        # )
