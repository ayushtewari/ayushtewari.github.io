import torch
import numpy as np
from Flow import softsplat as softsplat
import cv2

im = torch.from_numpy(cv2.imread("Flow/images/000000.png"))
im = im.permute(2, 0, 1)[None].to(dtype=torch.float32, device="cuda") / 255.0

flow = torch.zeros((1, 2, 64, 64), dtype=torch.float32, device=im.device)
flow[:, 0, :, :] = -10.25

print(im.shape, flow.shape)

tenAverage = softsplat.softsplat(tenIn=im, tenFlow=flow, tenMetric=None, strMode="avg")
print(tenAverage.shape)
cv2.imwrite(
    "Flow/images/000000_out.png",
    (tenAverage[0] * 255).permute(1, 2, 0).cpu().numpy().astype(np.uint8),
)
