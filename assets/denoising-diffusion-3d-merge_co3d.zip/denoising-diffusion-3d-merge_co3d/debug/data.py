from data_io.realestate10k import RealEstate10kDatasetOM as R

d = R(
    root="/om/data/public/RealEstate10k/",
    stage="test",
    num_target=1,
    context_min_distance=3,
    context_max_distance=5,
    max_scenes=100,
)

s = d[0]
