import os

# iterate over directories in wandb/ dir
dirs = os.listdir("wandb/")
for dir in dirs:
    if os.path.isdir(os.path.join("wandb", dir)):
        files = os.listdir(os.path.join("wandb", dir, "files"))
        ckpts = [f for f in files if f.endswith(".pt")]
        # sort ckpts by epoch
        ckpts = sorted(ckpts, key=lambda x: int(x.split("-")[1].split(".")[0]))
        # delete all but the last 2
        print(dir, ckpts)
        for ckpt in ckpts[:-2]:
            print("deleting", os.path.join("wandb", dir, "files", ckpt))
            os.remove(os.path.join("wandb", dir, "files", ckpt))

        # print(dir, ckpts)
        # exit()
