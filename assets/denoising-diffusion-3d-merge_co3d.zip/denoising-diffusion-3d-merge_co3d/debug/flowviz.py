from Flow.visualize_flow import visualizeFlow
from PIL import Image
import numpy as np

img = Image.open("flow_viz/0.jpg")
# resize to 64
img = img.resize((64, 64))
img = np.array(img).astype(np.float32) / 255.0

flow = np.random.randn(64, 64, 2)
flow[:32] = -1.0
flow[32:] = 1.0

print(f"img {img.shape} flow {flow.shape}")
visualizeFlow(img, flow, "flow_viz")
