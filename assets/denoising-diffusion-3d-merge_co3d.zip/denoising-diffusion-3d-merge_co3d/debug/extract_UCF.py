import os
import cv2

# Function to extract frames from a video file
def extract_frames(video_path, output_folder):
    cap = cv2.VideoCapture(video_path)
    frame_count = 0
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        # Save frame as image file
        frame_filename = os.path.join(output_folder, f"frame_{frame_count}.jpg")
        cv2.imwrite(frame_filename, frame)
        frame_count += 1
    cap.release()


# Function to process all videos in a folder
def process_folder(folder_path, output_folder):
    # Loop through all files and subdirectories in the folder
    for filename in os.listdir(folder_path):
        filepath = os.path.join(folder_path, filename)
        # Check if the file is a video file
        if os.path.isfile(filepath) and filename.endswith((".mp4", ".avi", ".mov")):
            print(f"Processing {os.path.join(folder_path,filename)}...")
            # Extract frames from the video file
            output_subfolder = os.path.join(
                output_folder, folder_path, filename.split(".")[0]
            )
            os.makedirs(output_subfolder, exist_ok=True)
            extract_frames(filepath, output_subfolder)
        # If the file is a directory, process it recursively
        elif os.path.isdir(filepath):
            process_folder(filepath, output_folder)


# Example usage
# input_folder = "/nobackup/nvme1/UCF/UCF-101/"
input_folder = "/scratch2/weka/tenenbaum/ayusht/datasets/UCF101/UCF-101/"
process_folder(input_folder, input_folder)
