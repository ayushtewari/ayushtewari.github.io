# import sys
# import os
# import torch
#
# sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
#
from PixelNeRF import PixelNeRFEncoder, PixelNeRFEncoderOriginal, PixelNeRFModelVanilla

# from denoising_diffusion_pytorch import Unet
#
# from data_io import NMRDataset, SMDataset
# from utils import to_gpu
#
# dataset = SMDataset(
#     root="/scratch2/weka/tenenbaum/ayusht/datasets/shepherd-metzler", near=0.8, far=1.8
# )
# data_loader = torch.utils.data.DataLoader(
#     dataset, batch_size=2, num_workers=1, shuffle=False,
# )
# sample = next(iter(data_loader))
# print(sample[0].keys())
# model_inp, gt = sample
# model_inp, gt = to_gpu(model_inp, "cuda"), to_gpu(gt, "cuda")


import torch
from PixelNeRF.transformer.DiT import DiT
from PixelNeRF.transformer.uvit import UViT

############# DIT ################
# model = DiT(
#     depth=28,
#     hidden_size=1152,
#     patch_size=2,
#     num_heads=16,
#     in_channels=3,
#     out_channels=512,
# ).cuda()

############# UViT ################
model = UViT(dim=64, cond_feats_dim=64, out_dim=512).cuda()

# I = torch.randn(1, 3, 32, 32).cuda()
# t = torch.randint(0, 1, (1,)).long().to("cuda")
# y = torch.randint(0, 1, (1,)).long().to("cuda")
# o = model(I, t, y)
# print(o.shape)

############# ResNet one downsampling + DiT  ################
# from PixelNeRF.resnet import PixelNeRFTimeEmbed, BasicBlockTimeEmbed

# model = DiT(
#     depth=28,
#     hidden_size=1152,
#     patch_size=2,
#     num_heads=16,
#     in_channels=64,
#     out_channels=512,
# ).cuda()

I = torch.randn(1, 3, 64, 64).cuda()
t = torch.randint(0, 1, (1,)).long().to("cuda")
y = torch.randint(0, 1, (1,)).long().to("cuda")
o = model(I, t)
print(o.shape)


# from einops import repeat
# from PixelNeRF.transformer.midas.dpt_depth import DPTDepthModel
# import torch.nn as nn

# enc = DPTDepthModel(
#     path="/scratch2/weka/tenenbaum/ayusht/checkpoints/midas/dpt_large_384.pt",
#     backbone="vitb_rn50_384",
# backbone="vitl16_384",
# non_negative=True,
# )


# pose = torch.eye(4)
# pose = repeat(pose, "h w -> n (h w)", n=1)
# o = enc(I, pose, nviews=1)
# print([s.shape for s in o])
# conv_map = nn.Conv2d(3, 64, kernel_size=7, stride=1, padding=3)
# o = conv_map(I)
# print(o.shape)


# t = torch.randint(0, 1000, (1,)).long().to("cuda")

# umodel = Unet(dim=64, dim_mults=(1, 2, 2, 4))
# ux = umodel(I, t)
# print(ux.shape)

# model = PixelNeRFEncoderOriginal()
# x = model(I)

# model = PixelNeRFEncoder(dims=64, dim_mults=(1, 1, 2, 4))
# x = model(I, t)

# model = PixelNeRFModelVanilla(near=1.2, far=4.0, model="vit").to("cuda")
# o = model.get_feats(I, None)
# print(o.shape)
# x = model(model_inp, t)

# print(x.shape, model_inp["ctxt_rgb"].shape)
